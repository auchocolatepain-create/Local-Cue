package dev.localcue

import android.content.Context

/**
 * The single place that decides what a cue looks like.
 *
 * Both triggers -- the notification listener and the live screen scanner --
 * route through deliver(), so the two paths can never drift apart in how they
 * clean, judge, or suppress an answer. They used to have separate copies of
 * this logic and they had already diverged.
 */
object Cue {

    /** The refusal token. Deliberately not "NOTHING": that word turns up in ordinary replies. */
    private const val DECLINE = "NONE"

    private const val MAX_CUE_CHARS = 200
    private const val FALLBACK_CHARS = 160

    fun clean(raw: String): String = raw.trim().trim('"', '\'', '.', ' ', '\n')

    /**
     * Only a reply that *starts* with the refusal token counts as a decline.
     * The old check was contains(), which discarded any useful answer that
     * happened to include the word.
     */
    fun isDecline(cleaned: String): Boolean {
        if (cleaned.isEmpty()) return true
        return cleaned.trimStart().uppercase().startsWith(DECLINE)
    }

    fun deliver(ctx: Context, raw: String, hits: List<Memory>, tag: String) {
        val cleaned = clean(raw)

        if (!isDecline(cleaned) && cleaned.length <= MAX_CUE_CHARS) {
            Diag.log("$tag cue shown: \"${cleaned.take(60)}\"")
            Notifications.showCue(ctx, cleaned)
            return
        }

        // The keyword prefilter already found something relevant. Staying silent
        // because a 1B model was unsure throws away a real match, so unless you
        // turn this off, show the note itself.
        if (Prefs.fallbackCue(ctx) && hits.isNotEmpty()) {
            Diag.log("$tag model declined -> showing the saved note instead")
            Notifications.showCue(ctx, hits.first().text.take(FALLBACK_CHARS))
            return
        }

        Diag.log("$tag model declined, no fallback (raw: \"${raw.take(60)}\")")
    }
}
