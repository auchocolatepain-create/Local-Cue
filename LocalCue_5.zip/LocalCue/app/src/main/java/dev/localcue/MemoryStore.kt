package dev.localcue

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Everything the model is allowed to know.
 *
 * Stored as a single JSON file inside the app's private data directory
 * (/data/data/dev.localcue/files/memory.json). Android's per-app UID sandbox
 * means no other app on the device can read it. It is never uploaded because
 * this app cannot reach the network at all -- see AndroidManifest.xml.
 *
 * Nothing enters this store unless you put it there: by tapping the tile,
 * tapping the notification action, or sharing text to the app.
 * Incoming messages are read to decide whether to show a cue, and are then
 * discarded. They are never written here.
 */
data class Memory(val id: Long, val source: String, val text: String)

object MemoryStore {

    private const val FILE = "memory.json"
    private const val MAX_ENTRIES = 250
    private const val MAX_CHARS_PER_ENTRY = 4000

    private var cache: MutableList<Memory>? = null

    @Synchronized
    fun all(ctx: Context): List<Memory> {
        cache?.let { return it }
        val f = File(ctx.filesDir, FILE)
        val list = mutableListOf<Memory>()
        if (f.exists()) {
            runCatching {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(Memory(o.getLong("id"), o.getString("source"), o.getString("text")))
                }
            }
        }
        cache = list
        return list
    }

    @Synchronized
    fun add(ctx: Context, source: String, text: String): Boolean {
        val clean = text.trim().replace(Regex("\\s+"), " ")
        if (clean.length < 15) return false
        val list = all(ctx).toMutableList()
        // Skip near-duplicates of the most recent entry.
        if (list.isNotEmpty() && list.last().text == clean) return false
        list.add(Memory(System.currentTimeMillis(), source, clean.take(MAX_CHARS_PER_ENTRY)))
        while (list.size > MAX_ENTRIES) list.removeAt(0)
        persist(ctx, list)
        return true
    }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        val list = all(ctx).filter { it.id != id }.toMutableList()
        persist(ctx, list)
    }

    @Synchronized
    fun clear(ctx: Context) = persist(ctx, mutableListOf())

    private fun persist(ctx: Context, list: MutableList<Memory>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("source", it.source).put("text", it.text))
        }
        File(ctx.filesDir, FILE).writeText(arr.toString())
        cache = list
    }

    // ---- Retrieval -------------------------------------------------------

    private val STOP = setOf(
        "this", "that", "with", "have", "from", "your", "will", "what", "when",
        "they", "them", "then", "there", "here", "been", "were", "which", "about",
        "would", "could", "should", "into", "just", "like", "than", "also", "much"
    )

    private fun tokens(s: String): Set<String> =
        s.lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 4 && it !in STOP }
            .toSet()

    /**
     * Cheap keyword overlap scoring. This runs in microseconds and exists purely
     * to keep the model asleep: if nothing in memory overlaps with the incoming
     * message, we never wake the LLM at all. That single decision is the biggest
     * battery saving in the whole app.
     */
    fun relevant(ctx: Context, query: String, limit: Int = 4): List<Memory> {
        val q = tokens(query)
        if (q.isEmpty()) return emptyList()
        return all(ctx)
            .map { it to tokens(it.text).count { t -> t in q } }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
    }
}
