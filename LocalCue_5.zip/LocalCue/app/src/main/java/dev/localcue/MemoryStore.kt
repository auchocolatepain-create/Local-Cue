package dev.localcue

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Everything the model is allowed to know.
 *
 * Stored as a single JSON file inside the app's private data directory
 * (/data/data/dev.localcue/files/memory.json). Android's per-app UID sandbox
 * means no other app on the device can read it. It is never uploaded because
 * this app cannot reach the network at all -- see AndroidManifest.xml.
 *
 * Nothing enters this store unless you put it there: by tapping the tile,
 * tapping the notification action, or sharing text to the app.
 * Incoming messages are read to decide whether to show a cue, and are then
 * discarded. They are never written here.
 */
data class Memory(
    val id: Long,
    val source: String,
    val text: String,
    /**
     * Related words generated once, locally, by the model itself -- see Enrich.
     * This is what lets "what groceries do you want?" find a note that only
     * says "butter, milk, bread". Empty until enrichment has run.
     */
    val keywords: String = ""
)

object MemoryStore {

    private const val FILE = "memory.json"
    private const val MAX_ENTRIES = 250
    private const val MAX_CHARS_PER_ENTRY = 4000

    private var cache: MutableList<Memory>? = null

    @Synchronized
    fun all(ctx: Context): List<Memory> {
        cache?.let { return it }
        val f = File(ctx.filesDir, FILE)
        val list = mutableListOf<Memory>()
        if (f.exists()) {
            runCatching {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Memory(
                            o.getLong("id"),
                            o.getString("source"),
                            o.getString("text"),
                            // Older files predate this field.
                            o.optString("keywords", "")
                        )
                    )
                }
            }
        }
        cache = list
        return list
    }

    @Synchronized
    fun add(ctx: Context, source: String, text: String): Boolean {
        val clean = text.trim().replace(Regex("\\s+"), " ")
        if (clean.length < 15) return false
        val list = all(ctx).toMutableList()
        // Compare against EVERY entry, not just the most recent. Capturing the
        // same screen twice an hour apart used to create a duplicate, which
        // then took a slot, cost an enrichment pass, and skewed the scoring.
        val fingerprint = clean.lowercase()
        if (list.any { it.text.lowercase() == fingerprint }) return false
        list.add(Memory(System.currentTimeMillis(), source, clean.take(MAX_CHARS_PER_ENTRY)))
        // Oldest first. Worth a line in the log: losing a note you saved months
        // ago to a cap you never saw is the kind of thing that erodes trust.
        while (list.size > MAX_ENTRIES) {
            list.removeAt(0)
            Diag.log("memory full at $MAX_ENTRIES, dropped the oldest entry")
        }
        persist(ctx, list)
        return true
    }

    @Synchronized
    fun setKeywords(ctx: Context, id: Long, keywords: String) {
        val list = all(ctx).map {
            if (it.id == id) it.copy(keywords = keywords) else it
        }.toMutableList()
        persist(ctx, list)
    }

    /**
     * @param includeFailed also return entries previously marked "-".
     *
     * Worth retrying by hand: the earlier English-only prompt made non-English
     * notes ramble until they timed out, and they were written off permanently
     * for a reason that was the prompt's fault, not the note's.
     */
    fun withoutKeywords(ctx: Context, includeFailed: Boolean = false): List<Memory> =
        all(ctx).filter { it.keywords.isBlank() || (includeFailed && it.keywords == "-") }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        persist(ctx, all(ctx).filter { it.id != id }.toMutableList())
    }

    @Synchronized
    fun clear(ctx: Context) = persist(ctx, mutableListOf())

    private fun persist(ctx: Context, list: MutableList<Memory>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("source", it.source)
                    .put("text", it.text)
                    .put("keywords", it.keywords)
            )
        }
        File(ctx.filesDir, FILE).writeText(arr.toString())
        cache = list
    }

    // ---- Retrieval -------------------------------------------------------

    private val STOP = setOf(
        "this", "that", "with", "have", "from", "your", "will", "what", "when",
        "they", "them", "then", "there", "here", "been", "were", "which", "about",
        "would", "could", "should", "into", "just", "like", "than", "also", "much",
        "the", "and", "for", "you", "are", "was", "our"
    )

    /**
     * Crude English plural stripping so "bottles" matches "bottle" and
     * "groceries" matches "grocery". Applied ONLY to Latin-script words:
     * blindly chopping a trailing "s" off other alphabets corrupts them.
     */
    private fun stem(w: String): String = when {
        w.length > 4 && w.endsWith("ies") -> w.dropLast(3) + "y"
        w.length > 4 && w.endsWith("ses") -> w.dropLast(2)
        w.length > 3 && w.endsWith("s") && !w.endsWith("ss") -> w.dropLast(1)
        else -> w
    }

    /** Han, Hiragana, Katakana, Hangul: scripts that do not separate words. */
    private fun isCjk(c: Char): Boolean = c.code in 0x3040..0x30FF ||
        c.code in 0x3400..0x4DBF || c.code in 0x4E00..0x9FFF || c.code in 0xAC00..0xD7AF

    /** Latin plus the common accented range, i.e. where stemming is sensible. */
    private fun isLatin(s: String) = s.all { it.code < 0x0250 }

    /**
     * Splitting on non-letters and demanding three characters works for
     * English and quietly fails elsewhere.
     *
     * Chinese, Japanese and Korean do not put spaces between words, so a whole
     * sentence arrived as ONE token that could never match anything -- CJK
     * memories were effectively unsearchable. Those are indexed as overlapping
     * character pairs instead, which is the standard trick for scripts without
     * word boundaries.
     *
     * Scripts that do use spaces (Persian, Arabic, Cyrillic, Greek) keep whole
     * words, but at a two-character floor, because plenty of real words there
     * are shorter than three.
     */
    private fun addTokens(chunk: String, into: MutableSet<String>) {
        if (chunk.isEmpty()) return

        if (chunk.any { isCjk(it) }) {
            if (chunk.length == 1) into.add(chunk)
            for (i in 0 until chunk.length - 1) into.add(chunk.substring(i, i + 2))
            return
        }

        val latin = isLatin(chunk)
        if (chunk.length < (if (latin) 3 else 2)) return
        if (latin && chunk in STOP) return
        into.add(if (latin) stem(chunk) else chunk)
    }

    private fun tokens(s: String): Set<String> {
        val out = HashSet<String>()
        for (chunk in s.lowercase().split(Regex("[^\\p{L}\\p{N}]+"))) {
            addTokens(chunk, out)
        }
        return out
    }

    /** Text plus the model-generated related words. */
    private fun indexOf(m: Memory): Set<String> =
        tokens(m.text) + tokens(m.keywords)

    /**
     * Cheap keyword overlap scoring. This runs in microseconds and exists purely
     * to keep the model asleep: if nothing in memory overlaps with the incoming
     * message, we never wake the LLM at all. That single decision is the biggest
     * battery saving in the whole app.
     *
     * Matches against the enriched index, so a note about butter and milk can be
     * found by the word "groceries" even though that word appears nowhere in it.
     */
    fun relevant(ctx: Context, query: String, limit: Int = 4): List<Memory> {
        val q = tokens(query)
        if (q.isEmpty()) return emptyList()
        return all(ctx)
            .map { it to indexOf(it).count { t -> t in q } }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
    }

    /** Exposed so the diagnostics screen can show exactly what was compared. */
    fun debugTokens(ctx: Context, query: String): String {
        val q = tokens(query)
        val sb = StringBuilder("query tokens: ${q.sorted()}\n")
        all(ctx).takeLast(6).forEach {
            val idx = indexOf(it)
            sb.append("  [${it.text.take(28)}] overlap=${idx.count { t -> t in q }}")
                .append(if (it.keywords.isBlank()) "  (NOT ENRICHED)" else "  (enriched)")
                .append('\n')
        }
        return sb.toString()
    }
}
