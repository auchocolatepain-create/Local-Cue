package dev.localcue

import android.content.Context

/**
 * Last-resort retrieval: ask the chat model which notes relate to the message.
 *
 * WHY THIS EXISTS
 * Keyword matching cannot connect "what time are we meeting?" to "dinner with
 * Sarah on Thursday". Embeddings can, but the only embedder MediaPipe will
 * actually load is English-centric, and no multilingual one is published in a
 * format it accepts -- so for Farsi there is nothing to install.
 *
 * The model you already have does speak Farsi. So instead of matching the
 * message against each note, hand it a numbered index of the notes and ask
 * which ones relate. It is the same retrieval job, done by the one component
 * that already understands the language.
 *
 * WHY IT DOES NOT WRECK THE BATTERY
 * It runs only when the free paths have already failed AND the message looks
 * like a question. That last gate matters: without it, every irrelevant
 * message would wake the model, which is exactly what the keyword prefilter
 * exists to prevent. The reply is a couple of digits, so the decode is tiny --
 * the cost is prefilling a short index, not writing an answer.
 */
object DeepSearch {

    /** Notes offered to the model. Newest first, because recent notes are asked about. */
    private const val INDEX_SIZE = 60
    private const val LINE_CHARS = 70

    /**
     * Punctuation is the strongest signal but far from the only one: plenty of
     * real requests never carry a question mark. Interrogative words are
     * checked too, in the scripts most likely to appear here.
     */
    private val QUESTION_WORDS = listOf(
        // English
        "what", "when", "where", "why", "who", "which", "how",
        "can you", "could you", "do you", "did you", "are you", "is there",
        "remind", "remember", "need",
        // Persian
        "چی", "چه", "کی", "کجا", "چرا", "چطور", "چگونه", "آیا", "کدام",
        "یادت", "لازم", "بگو",
        // Arabic
        "ما ", "متى", "أين", "لماذا", "كيف", "هل "
    )

    fun looksLikeAQuestion(text: String): Boolean {
        if (text.contains('?') || text.contains('؟') || text.contains('？')) return true
        val lower = text.lowercase()
        return QUESTION_WORDS.any { lower.contains(it) }
    }

    private fun shouldRun(ctx: Context, query: String): Boolean = when (Prefs.deepMode(ctx)) {
        Prefs.DEEP_OFF -> false
        Prefs.DEEP_ALWAYS -> true
        else -> looksLikeAQuestion(query)
    }

    fun find(ctx: Context, query: String, limit: Int = 3): List<Memory> {
        if (!shouldRun(ctx, query)) return emptyList()
        if (LlmEngine.isBusy()) return emptyList()

        val notes = MemoryStore.all(ctx).reversed().take(INDEX_SIZE)
        if (notes.isEmpty()) return emptyList()

        val prompt = buildString {
            append("Here are saved notes, numbered.\n")
            notes.forEachIndexed { i, m ->
                append(i + 1).append(". ").append(m.text.take(LINE_CHARS)).append('\n')
            }
            append("\nMessage: \"").append(query.takeLast(300)).append("\"\n")
            append("Which notes could help answer this message?\n")
            append("Reply with numbers separated by commas, or NONE. Nothing else.\n")
            append("Numbers:")
        }

        val answer = runCatching { LlmEngine.generate(ctx, prompt) }
            .onFailure { Diag.log("deep search failed: ${it::class.java.simpleName}") }
            .getOrNull() ?: return emptyList()

        // Anything that is not a number is the model ignoring the instruction.
        val picked = Regex("\\d+").findAll(answer.take(60))
            .mapNotNull { it.value.toIntOrNull() }
            .filter { it in 1..notes.size }
            .distinct()
            .take(limit)
            .map { notes[it - 1] }
            .toList()

        Diag.log(
            if (picked.isEmpty()) "deep search: model picked nothing"
            else "deep search: model picked ${picked.size} note(s)"
        )
        return picked
    }
}
