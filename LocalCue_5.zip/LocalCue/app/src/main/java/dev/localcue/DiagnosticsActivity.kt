package dev.localcue

import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Built in code rather than XML so it stays a single self-contained file.
 */
class DiagnosticsActivity : AppCompatActivity() {

    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTitle(R.string.diagnostics)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val input = EditText(this).apply {
            hint = getString(R.string.test_message_hint)
            inputType = InputType.TYPE_CLASS_TEXT
            setText(R.string.test_message_default)
        }
        column.addView(input, wide())

        val runButton = Button(this).apply { setText(R.string.run_test) }
        column.addView(runButton, wide())

        val enrichButton = Button(this).apply { setText(R.string.enrich_memories) }
        column.addView(enrichButton, wide())

        val benchButton = Button(this).apply { setText(R.string.run_benchmark) }
        column.addView(benchButton, wide())

        val resetButton = Button(this).apply { setText(R.string.reset_model) }
        column.addView(resetButton, wide())

        val promptButton = Button(this).apply { setText(R.string.show_prompt) }
        column.addView(promptButton, wide())

        val logButton = Button(this).apply { setText(R.string.show_log) }
        column.addView(logButton, wide())

        val clearButton = Button(this).apply { setText(R.string.clear_log) }
        column.addView(clearButton, wide())

        output = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
        }
        column.addView(output, wide())

        setContentView(ScrollView(this).apply { addView(column) })

        runButton.setOnClickListener {
            val message = input.text.toString()
            output.setText(R.string.working)
            // Inference blocks for seconds; never run it on the main thread.
            Thread {
                val report = runCatching { Diag.selfTest(applicationContext, message) }
                    .getOrElse { "Self test crashed:\n${it.stackTraceToString()}" }
                runOnUiThread { output.text = report }
            }.start()
        }

        enrichButton.setOnClickListener {
            output.setText(R.string.enriching)
            Thread {
                val n = runCatching {
                    Enrich.run(applicationContext, max = 25, includeFailed = true) { done, total ->
                        runOnUiThread {
                            output.text = getString(R.string.enrich_progress, done, total)
                        }
                    }
                }.getOrDefault(0)
                runOnUiThread {
                    output.text = getString(R.string.enriched_n, n) + "\n\n" + Diag.dump()
                }
            }.start()
        }

        benchButton.setOnClickListener {
            output.setText(R.string.working)
            Thread {
                val report = runCatching { LlmEngine.benchmark(applicationContext) }
                    .getOrElse { "Benchmark failed:\n${it::class.java.simpleName}: ${it.message}" }
                runOnUiThread { output.text = report }
            }.start()
        }

        resetButton.setOnClickListener {
            LlmEngine.forceReset()
            output.text = getString(R.string.reset_done)
        }

        promptButton.setOnClickListener { output.text = Diag.lastExchange() }

        logButton.setOnClickListener { output.text = Diag.dump() }
        clearButton.setOnClickListener {
            Diag.clear()
            output.text = Diag.dump()
        }

        output.text = Diag.dump()
    }

    private fun wide() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
