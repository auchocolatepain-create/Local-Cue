package dev.localcue

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig

/**
 * The newer Google runtime, used for .litertlm models.
 *
 * Why it exists alongside MediaPipe:
 *  - GPU acceleration that actually works on this phone.
 *  - It is the only runtime that reads .litertlm, which is the format the
 *    bigger and multilingual models ship in (Gemma 3n, Gemma 4).
 *  - It can CANCEL a running generation. MediaPipe's blocking API cannot,
 *    which is why a runaway reply there can only be bounded by shrinking the
 *    whole context window.
 *
 * Backends:
 *  CPU  always available.
 *  GPU  needs the two <uses-native-library> OpenCL entries in the manifest.
 *  NPU  needs vendor dispatch libraries compiled from source with Bazel and
 *       NDK r28b and bundled in jniLibs. They are NOT in any Maven artifact,
 *       so selecting NPU here will fail until those are built. The failure is
 *       reported plainly rather than silently falling back, because pretending
 *       the NPU is in use would be worse than saying it is not.
 *
 * Like everything else here this is local computation only. The app has no
 * INTERNET permission, and the manifest actively strips it if a dependency
 * tries to add one.
 */
object LiteRtLmBackend {

    fun handles(path: String): Boolean = path.endsWith(".litertlm", ignoreCase = true)

    fun create(ctx: Context, path: String): Engine {
        val choice = Prefs.backend(ctx)
        val backend = when (choice) {
            Prefs.BACKEND_GPU -> Backend.GPU()
            Prefs.BACKEND_NPU -> Backend.NPU(
                nativeLibraryDir = ctx.applicationInfo.nativeLibraryDir
            )
            else -> Backend.CPU()
        }

        Diag.log("LiteRT-LM: initialising on ${Prefs.backendName(choice)}")

        val engine = Engine(
            EngineConfig(
                modelPath = path,
                backend = backend,
                maxNumTokens = Prefs.contextTokens(ctx),
                // A writable cache makes the second and later loads much faster.
                cacheDir = ctx.cacheDir.path
            )
        )
        engine.initialize()
        return engine
    }

    /**
     * One stateless turn.
     *
     * This used to stream and call cancelProcess() plus close() the moment a
     * length or time cap was hit. That is what was crashing the app: flow
     * cancellation is not synchronous, so close() could run
     * nativeDeleteConversation while the decode thread was still inside the
     * conversation -- a use-after-free, surfacing as a random native crash.
     * I flagged exactly that hazard when writing forceReset(), then did it
     * anyway one build later.
     *
     * Back to the blocking call, which never had that problem. The runaway
     * generations those caps existed to stop came from enrichment, and
     * enrichment is gone -- semantic matching is done by the embedder now, so
     * the model is only ever asked to write one short cue.
     *
     * Message has no `text` property despite what the Android guide shows: in
     * the library source Message.toString() delegates to Contents.toString(),
     * which is why Google's own sample prints the Message directly.
     */
    fun ask(engine: Engine, prompt: String): String =
        engine.createConversation().use { conversation ->
            conversation.sendMessage(prompt).toString()
        }
}
