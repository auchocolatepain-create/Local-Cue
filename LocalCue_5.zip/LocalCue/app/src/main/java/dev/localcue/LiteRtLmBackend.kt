package dev.localcue

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull

/**
 * The newer Google runtime, used for .litertlm models.
 *
 * Why it exists alongside MediaPipe:
 *  - GPU acceleration that actually works on this phone.
 *  - It is the only runtime that reads .litertlm, which is the format the
 *    bigger and multilingual models ship in (Gemma 3n, Gemma 4).
 *  - It can CANCEL a running generation. MediaPipe's blocking API cannot,
 *    which is why a runaway reply there can only be bounded by shrinking the
 *    whole context window.
 *
 * Backends:
 *  CPU  always available.
 *  GPU  needs the two <uses-native-library> OpenCL entries in the manifest.
 *  NPU  needs vendor dispatch libraries compiled from source with Bazel and
 *       NDK r28b and bundled in jniLibs. They are NOT in any Maven artifact,
 *       so selecting NPU here will fail until those are built. The failure is
 *       reported plainly rather than silently falling back, because pretending
 *       the NPU is in use would be worse than saying it is not.
 *
 * Like everything else here this is local computation only. The app has no
 * INTERNET permission, and the manifest actively strips it if a dependency
 * tries to add one.
 */
object LiteRtLmBackend {

    fun handles(path: String): Boolean = path.endsWith(".litertlm", ignoreCase = true)

    fun create(ctx: Context, path: String): Engine {
        val choice = Prefs.backend(ctx)
        val backend = when (choice) {
            Prefs.BACKEND_GPU -> Backend.GPU()
            Prefs.BACKEND_NPU -> Backend.NPU(
                nativeLibraryDir = ctx.applicationInfo.nativeLibraryDir
            )
            else -> Backend.CPU()
        }

        Diag.log("LiteRT-LM: initialising on ${Prefs.backendName(choice)}")

        val engine = Engine(
            EngineConfig(
                modelPath = path,
                backend = backend,
                maxNumTokens = Prefs.contextTokens(ctx),
                // A writable cache makes the second and later loads much faster.
                cacheDir = ctx.cacheDir.path
            )
        )
        engine.initialize()
        return engine
    }

    /**
     * One stateless turn, bounded by BOTH length and time.
     *
     * The blocking sendMessage() has no output limit, so a model that keeps
     * going decodes until it exhausts the context. That is survivable in
     * English and punishing in other scripts: Persian, Arabic, Cyrillic and
     * CJK cost several times more tokens per character in Gemma's tokenizer,
     * so the same runaway takes minutes rather than seconds. A non-English
     * note used to look like enrichment had simply frozen.
     *
     * Streaming plus cancelProcess() ends it as soon as we have enough, which
     * MediaPipe cannot do at all.
     *
     * Message has no `text` property despite what the Android guide shows: in
     * the library source Message.toString() delegates to Contents.toString(),
     * which is why Google's own sample prints the Message directly.
     */
    fun ask(engine: Engine, prompt: String, maxChars: Int, maxMillis: Long): String {
        val conversation = engine.createConversation()
        val out = StringBuilder()
        try {
            val finished = runBlocking {
                withTimeoutOrNull(maxMillis) {
                    conversation.sendMessageAsync(prompt)
                        .takeWhile { out.length < maxChars }
                        .collect { out.append(it.toString()) }
                    true
                }
            }
            if (finished == null) {
                Diag.log("generation hit the ${maxMillis / 1000}s cap, cancelled")
            } else if (out.length >= maxChars) {
                Diag.log("generation hit the $maxChars character cap, cancelled")
            }
        } finally {
            // Stops the native decode whether we finished, capped out or threw.
            runCatching { conversation.cancelProcess() }
            runCatching { conversation.close() }
        }
        return out.toString()
    }
}
