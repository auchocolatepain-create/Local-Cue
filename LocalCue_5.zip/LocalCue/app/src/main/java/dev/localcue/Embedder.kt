package dev.localcue

import android.content.Context
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import java.io.File
import kotlin.math.sqrt

/**
 * Semantic matching. This is what keyword enrichment was a poor substitute for.
 *
 * WHY THE OLD DESIGN COULD NOT WORK
 * Enrichment asked the chat model, once per note, to guess every word someone
 * might use to ask about it. That fails in three ways that no amount of prompt
 * tuning fixes:
 *
 *  - Names. A note saying "dinner with Sarah on Thursday" cannot be reached by
 *    "what time are we meeting?" There is no word in common and no keyword list
 *    that anticipates it.
 *  - It is a one-shot guess at future phrasing, made before the question exists.
 *  - It cost a full LLM generation per note, which is where the non-English
 *    freezes came from.
 *
 * WHAT REPLACES IT
 * EmbeddingGemma turns text into a vector positioned by MEANING. "What time are
 * we meeting?" lands near "dinner with Sarah on Thursday" because they are about
 * the same thing, not because they share a word. It is trained on 100+
 * languages in one shared space, so a Persian question can match an English
 * note -- something keyword overlap can never do at any prompt quality.
 *
 * Cost: roughly 300 MB of model and tens of milliseconds per comparison. That
 * is a fraction of one chat-model generation, and it replaces a generation per
 * note entirely.
 *
 * Optional. With no embedding model chosen, everything falls back to the
 * existing keyword matching, so this can never make the app worse than it was.
 */
object Embedder {

    /**
     * Matryoshka truncation. EmbeddingGemma is trained so the leading
     * dimensions carry most of the meaning, which means we can keep 128 of 768
     * and store six times less per memory with little quality loss.
     */
    private const val DIMENSIONS = 128

    private var embedder: TextEmbedder? = null

    @Volatile
    var lastError: String? = null
        private set

    fun modelPresent(ctx: Context): Boolean =
        Prefs.embedModelPath(ctx)?.let { File(it).length() > 0 } == true

    fun enabled(ctx: Context): Boolean = Prefs.useEmbeddings(ctx) && modelPresent(ctx)

    @Synchronized
    fun unload() {
        runCatching { embedder?.close() }
        embedder = null
    }

    @Synchronized
    private fun ensureLoaded(ctx: Context): TextEmbedder? {
        embedder?.let { return it }
        val path = Prefs.embedModelPath(ctx) ?: return null
        return runCatching {
            val options = TextEmbedder.TextEmbedderOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath(path).build())
                .build()
            TextEmbedder.createFromOptions(ctx.applicationContext, options).also {
                embedder = it
                lastError = null
                Diag.log("embedder loaded")
            }
        }.onFailure {
            lastError = "${it::class.java.simpleName}: ${it.message}"
            Diag.log("embedder FAILED to load: $lastError")
        }.getOrNull()
    }

    /**
     * What this accepts, and what it does not.
     *
     * MediaPipe TextEmbedder needs the TOKENIZER BUNDLED WITH THE MODEL: a
     * .task bundle, or a .tflite carrying embedded metadata. It cannot use
     * a model.safetensors (that is the PyTorch training format, with no
     * TFLite graph at all), nor a bare .tflite accompanied by a separate
     * sentencepiece.model -- which is unfortunately how EmbeddingGemma is
     * published on Hugging Face today.
     */
    fun acceptedFormats(): String = "task, tflite"

    /** Null when no model is set up or the model rejects the text. */
    fun embed(ctx: Context, text: String): FloatArray? {
        val engine = ensureLoaded(ctx) ?: return null
        return runCatching {
            val raw = engine.embed(text.take(2000))
                .embeddingResult()
                .embeddings()
                .first()
                .floatEmbedding()
            normalise(raw.copyOf(minOf(DIMENSIONS, raw.size)))
        }.onFailure {
            lastError = "${it::class.java.simpleName}: ${it.message}"
            Diag.log("embed FAILED: $lastError")
        }.getOrNull()
    }

    /** Unit length, so cosine similarity is just the dot product. */
    private fun normalise(v: FloatArray): FloatArray {
        var sum = 0.0
        for (x in v) sum += x.toDouble() * x
        val length = sqrt(sum).toFloat()
        if (length <= 0f) return v
        for (i in v.indices) v[i] = v[i] / length
        return v
    }

    /** Both sides are already unit length, so this is the cosine. */
    fun similarity(a: FloatArray, b: FloatArray): Float {
        val n = minOf(a.size, b.size)
        var dot = 0f
        for (i in 0 until n) dot += a[i] * b[i]
        return dot
    }
}
