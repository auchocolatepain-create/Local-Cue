package dev.localcue

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Settings moved off the main screen.
 *
 * The main screen had grown to a dozen controls plus the memory list, with no
 * ScrollView -- on a shorter display the bottom was simply unreachable, and a
 * ScrollView could not be added because it wraps a ListView, which breaks
 * scrolling. Splitting the screen fixes the overflow properly and lets the
 * memory list keep the space it needs.
 *
 * Built in code so there is no second layout file to keep in sync.
 */
class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTitle(R.string.settings)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(textRes: Int) {
            column.addView(
                TextView(this).apply {
                    setText(textRes)
                    setPadding(0, pad / 2, 0, 0)
                    textSize = 13f
                },
                wide()
            )
        }

        fun check(textRes: Int, get: () -> Boolean, set: (Boolean) -> Unit) {
            column.addView(
                CheckBox(this).apply {
                    setText(textRes)
                    isChecked = get()
                    setOnCheckedChangeListener { _, v -> set(v) }
                },
                wide()
            )
        }

        fun choice(labelRes: Int, arrayRes: Int, get: () -> Int, set: (Int) -> Unit) {
            label(labelRes)
            column.addView(
                Spinner(this).apply {
                    adapter = ArrayAdapter.createFromResource(
                        this@SettingsActivity, arrayRes, android.R.layout.simple_spinner_item
                    ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
                    setSelection(get().coerceIn(0, count - 1))
                    onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(
                            parent: AdapterView<*>?, view: android.view.View?, pos: Int, id: Long
                        ) {
                            if (pos != get()) set(pos)
                        }

                        override fun onNothingSelected(parent: AdapterView<*>?) {}
                    }
                },
                wide()
            )
        }

        fun button(textRes: Int, onClick: () -> Unit) {
            column.addView(
                Button(this).apply {
                    setText(textRes)
                    setOnClickListener { onClick() }
                },
                wide()
            )
        }

        label(R.string.section_permissions)
        button(R.string.btn_notif_access) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button(R.string.btn_accessibility) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        label(R.string.section_behaviour)
        check(R.string.cb_enabled, { Prefs.enabled(this) }) {
            Prefs.setEnabled(this, it)
            if (it) Notifications.showControl(this) else Notifications.hideControl(this)
        }
        check(R.string.cb_live, { Prefs.liveScan(this) }) { Prefs.setLiveScan(this, it) }
        check(R.string.cb_fallback, { Prefs.fallbackCue(this) }) { Prefs.setFallbackCue(this, it) }
        check(R.string.cb_screen_on, { Prefs.onlyWhenScreenOn(this) }) {
            Prefs.setOnlyWhenScreenOn(this, it)
        }

        choice(R.string.backend_label, R.array.backends, { Prefs.backend(this) }) {
            Prefs.setBackend(this, it)
        }
        choice(R.string.context_label, R.array.context_sizes, { Prefs.contextChoice(this) }) {
            Prefs.setContextChoice(this, it)
        }
        choice(R.string.battery_label, R.array.battery_floors, { Prefs.batteryChoice(this) }) {
            Prefs.setBatteryChoice(this, it)
        }

        val cooldownLabel = TextView(this).apply {
            text = getString(R.string.cooldown, (Prefs.cooldownMs(this@SettingsActivity) / 1000).toInt())
            setPadding(0, pad / 2, 0, 0)
        }
        column.addView(cooldownLabel, wide())
        column.addView(
            SeekBar(this).apply {
                max = 590
                progress = ((Prefs.cooldownMs(this@SettingsActivity) / 1000L).toInt() - 10)
                    .coerceIn(0, 590)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        cooldownLabel.text = getString(R.string.cooldown, p + 10)
                    }

                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {
                        Prefs.setCooldownSec(this@SettingsActivity, (s?.progress ?: 80) + 10)
                    }
                })
            },
            wide()
        )

        label(R.string.section_matching)
        check(R.string.cb_embeddings, { Prefs.useEmbeddings(this) }) {
            Prefs.setUseEmbeddings(this, it)
        }
        choice(R.string.threshold_label, R.array.thresholds, { Prefs.thresholdChoice(this) }) {
            Prefs.setThresholdChoice(this, it)
        }
        choice(R.string.deep_label, R.array.deep_modes, { Prefs.deepMode(this) }) {
            Prefs.setDeepMode(this, it)
        }

        label(R.string.section_privacy)
        check(R.string.cb_verbose, { Prefs.verboseLog(this) }) { Prefs.setVerboseLog(this, it) }

        label(R.string.section_danger)
        button(R.string.btn_clear) {
            AlertDialog.Builder(this)
                .setMessage(R.string.confirm_clear)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    MemoryStore.clear(this)
                    Toast.makeText(this, R.string.cleared, Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }

        column.addView(
            TextView(this).apply {
                setText(R.string.settings_footer)
                setPadding(0, pad, 0, 0)
                textSize = 12f
            },
            wide()
        )

        setContentView(ScrollView(this).apply { addView(column) })
    }

    private fun wide() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
