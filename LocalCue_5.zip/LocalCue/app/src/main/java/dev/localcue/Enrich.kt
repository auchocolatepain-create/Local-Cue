package dev.localcue

/**
 * Teaches the keyword prefilter the words you would actually use.
 *
 * The problem: a note saying "butter, milk, bread" shares no word with
 * "what groceries do you want?", so the lexical prefilter never fired and the
 * model was never woken. Embeddings would solve it, but that means shipping a
 * second model and running a vector comparison on every message.
 *
 * Instead the work is moved to save time. Once per memory -- an event you
 * trigger by hand and which happens rarely -- the local model is asked for the
 * words someone might use to ask about that note. Those are stored alongside it
 * and folded into the same cheap token overlap.
 *
 * Cost at match time: exactly zero, it is still set intersection.
 * Cost at save time: one short inference.
 * Nothing leaves the device; this uses the same local model as everything else.
 */
object Enrich {

    private const val MAX_KEYWORDS = 20

    private fun prompt(noteText: String): String = buildString {
        // Both examples were English, so a Persian or Russian note had to break
        // the demonstrated pattern -- and the model would ramble instead of
        // stopping. The second example is deliberately non-Latin so the shape
        // generalises, and the instruction now asks for BOTH the note's own
        // language and English, because you may ask in either.
        append("List search words for this note.\n")
        append("Use the same language as the note, then the English equivalents.\n")
        append("Comma separated single words. No sentences. Stop after the words.\n\n")
        append("Note: \"eggs, butter, bread, milk\"\n")
        append("Words: groceries, shopping, supermarket, food, store, buy, list\n\n")
        append("Note: \"قرار ملاقات دکتر ساعت ۳ روز سه‌شنبه\"\n")
        append("Words: دکتر, ملاقات, قرار, پزشک, وقت, doctor, appointment, tuesday\n\n")
        append("Note: \"").append(noteText.take(300)).append("\"\n")
        append("Words:")
    }

    /**
     * Two characters is a real word in many scripts, so the old 3-character
     * floor quietly discarded most of a non-Latin keyword list.
     */
    private fun sanitise(raw: String): String =
        raw.lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .map { it.trim() }
            .filter { it.length in 2..24 }
            .distinct()
            .take(MAX_KEYWORDS)
            .joinToString(" ")

    /**
     * Enriches up to [max] un-enriched memories. Blocking: call from a
     * background thread. Returns how many were done.
     *
     * Skips silently when the model is busy so it can never contend with a
     * live cue, which is always the higher priority.
     */
    fun run(
        ctx: android.content.Context,
        max: Int = 10,
        includeFailed: Boolean = false,
        onProgress: ((done: Int, total: Int) -> Unit)? = null
    ): Int {
        var done = 0
        val queue = MemoryStore.withoutKeywords(ctx, includeFailed).take(max)
        for (memory in queue) {
            onProgress?.invoke(done, queue.size)
            if (LlmEngine.isBusy()) {
                Diag.log("enrich: model busy, stopping after $done")
                break
            }
            // Leave a gap between items. Enrichment is never urgent; an actual
            // cue is. Without this, a long batch could hold the single-flight
            // engine for minutes and silently drop live messages.
            if (done > 0) runCatching { Thread.sleep(400) }
            // Short and hard-capped. A keyword list that has not finished in
            // 25 seconds is not going to be useful.
            val outcome = runCatching {
                LlmEngine.generate(ctx, prompt(memory.text), maxChars = 250, maxMillis = 25_000L)
            }
            val words = outcome.getOrNull()?.let { sanitise(it) }

            if (words.isNullOrBlank()) {
                val cause = outcome.exceptionOrNull()
                val transient = cause is LlmEngine.ModelMissing || cause is LlmEngine.Busy
                Diag.logContent(
                    ctx,
                    "enrich failed: " + (cause?.message ?: "empty reply") +
                        if (transient) " (will retry)" else "",
                    "-- note was \"${memory.text.take(30)}\""
                )

                // Only give up permanently when the model actually answered and
                // produced nothing useful. Marking a note "-" because no model
                // was loaded yet left it unmatched forever, and notes are
                // usually added BEFORE the model is chosen.
                if (transient) break
                MemoryStore.setKeywords(ctx, memory.id, "-")
                continue
            }

            MemoryStore.setKeywords(ctx, memory.id, words)
            Diag.logContent(ctx, "enriched a note (${words.split(" ").size} words)",
                "\"${memory.text.take(24)}\" -> $words")
            done++
        }
        return done
    }

    /** Fire-and-forget enrichment after a new memory is saved. */
    fun runInBackground(ctx: android.content.Context) {
        val app = ctx.applicationContext
        Thread {
            runCatching { run(app, max = 3) }
                .onFailure { Diag.log("enrich crashed: ${it.message}") }
        }.start()
    }
}
