package dev.localcue

/**
 * Teaches the keyword prefilter the words you would actually use.
 *
 * The problem: a note saying "butter, milk, bread" shares no word with
 * "what groceries do you want?", so the lexical prefilter never fired and the
 * model was never woken. Embeddings would solve it, but that means shipping a
 * second model and running a vector comparison on every message.
 *
 * Instead the work is moved to save time. Once per memory -- an event you
 * trigger by hand and which happens rarely -- the local model is asked for the
 * words someone might use to ask about that note. Those are stored alongside it
 * and folded into the same cheap token overlap.
 *
 * Cost at match time: exactly zero, it is still set intersection.
 * Cost at save time: one short inference.
 * Nothing leaves the device; this uses the same local model as everything else.
 */
object Enrich {

    private const val MAX_KEYWORDS = 20

    private fun prompt(noteText: String): String = buildString {
        append("List the words someone might use when asking about this note.\n")
        append("Include general category words, not just words already in it.\n")
        append("Comma separated single words. No explanation.\n\n")
        append("Note: \"eggs, butter, bread, milk\"\n")
        append("Words: groceries, shopping, supermarket, food, store, buy, list, dairy, bakery\n\n")
        append("Note: \"Flight BA142 leaves 18:40 from Heathrow T5\"\n")
        append("Words: flight, plane, airport, travel, departure, time, terminal, trip, heathrow\n\n")
        append("Note: \"").append(noteText.take(300)).append("\"\n")
        append("Words:")
    }

    private fun sanitise(raw: String): String =
        raw.lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .map { it.trim() }
            .filter { it.length in 3..20 }
            .distinct()
            .take(MAX_KEYWORDS)
            .joinToString(" ")

    /**
     * Enriches up to [max] un-enriched memories. Blocking: call from a
     * background thread. Returns how many were done.
     *
     * Skips silently when the model is busy so it can never contend with a
     * live cue, which is always the higher priority.
     */
    fun run(ctx: android.content.Context, max: Int = 10): Int {
        var done = 0
        for (memory in MemoryStore.withoutKeywords(ctx).take(max)) {
            if (LlmEngine.isBusy()) {
                Diag.log("enrich: model busy, stopping after $done")
                break
            }
            val outcome = runCatching { LlmEngine.generate(ctx, prompt(memory.text)) }
            val words = outcome.getOrNull()?.let { sanitise(it) }

            if (words.isNullOrBlank()) {
                Diag.log("enrich FAILED for \"${memory.text.take(30)}\": " +
                    (outcome.exceptionOrNull()?.message ?: "empty reply"))
                // Mark it so a permanently unhelpful note is not retried forever.
                MemoryStore.setKeywords(ctx, memory.id, "-")
                continue
            }

            MemoryStore.setKeywords(ctx, memory.id, words)
            Diag.log("enriched \"${memory.text.take(24)}\" -> $words")
            done++
        }
        return done
    }

    /** Fire-and-forget enrichment after a new memory is saved. */
    fun runInBackground(ctx: android.content.Context) {
        val app = ctx.applicationContext
        Thread {
            runCatching { run(app, max = 3) }
                .onFailure { Diag.log("enrich crashed: ${it.message}") }
        }.start()
    }
}
