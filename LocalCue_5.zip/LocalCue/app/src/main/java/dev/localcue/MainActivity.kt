package dev.localcue

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.format.DateUtils
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Status, the handful of things you actually do, and what is remembered.
 *
 * The screen is a single ListView with the controls attached as a header, so
 * everything scrolls together. The old fixed column could not be scrolled at
 * all once it outgrew the display.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var memoryList: ListView
    private lateinit var statusLabel: TextView
    private lateinit var memoryCount: TextView
    private lateinit var searchBox: EditText
    private lateinit var fixSetup: Button

    private lateinit var adapter: ArrayAdapter<String>

    /** What the list is currently showing, so a tap maps back to a Memory. */
    private var shown: List<Memory> = emptyList()

    private val pickModel = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> if (uri != null) importModel(uri) }

    private val askNotifications = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted && Prefs.enabled(this)) Notifications.showControl(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        memoryList = findViewById(R.id.memoryList)
        val header = layoutInflater.inflate(R.layout.main_header, memoryList, false)
        memoryList.addHeaderView(header, null, false)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        memoryList.adapter = adapter

        statusLabel = header.findViewById(R.id.statusLabel)
        memoryCount = header.findViewById(R.id.memoryCount)
        searchBox = header.findViewById(R.id.searchBox)
        fixSetup = header.findViewById(R.id.btnFixSetup)

        header.findViewById<Button>(R.id.btnAddNote).setOnClickListener { editNote(null) }
        header.findViewById<Button>(R.id.btnModel).setOnClickListener {
            pickModel.launch(arrayOf("*/*"))
        }
        header.findViewById<Button>(R.id.btnApps).setOnClickListener {
            startActivity(Intent(this, AppPickerActivity::class.java))
        }
        header.findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        header.findViewById<Button>(R.id.btnDiag).setOnClickListener {
            startActivity(Intent(this, DiagnosticsActivity::class.java))
        }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = renderList()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        // Positions include the header, so shift by headerViewsCount.
        memoryList.setOnItemClickListener { _, _, pos, _ ->
            val i = pos - memoryList.headerViewsCount
            if (i in shown.indices) showMemory(shown[i])
        }

        ensureNotificationPermission()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---- Setup state -----------------------------------------------------

    private data class Setup(
        val notifications: Boolean,
        val screen: Boolean,
        val apps: Int,
        val model: Boolean
    ) {
        val complete get() = notifications && screen && apps > 0 && model
    }

    private fun setup() = Setup(
        notifications = Diag.notificationAccessGranted(this),
        screen = ScreenReaderService.instance != null,
        apps = Prefs.watchedApps(this).size,
        model = Prefs.modelPath(this)?.let { File(it).length() > 0 } == true
    )

    /**
     * Rather than four cryptic OK/NOT SET markers, name the single next thing
     * that is missing and put a button on it.
     */
    private fun applySetupState() {
        val s = setup()
        if (s.complete) {
            statusLabel.text = getString(R.string.status_ready, Prefs.modelName(this).ifEmpty { "model" })
            fixSetup.visibility = View.GONE
            return
        }

        val (message, action) = when {
            !s.model -> R.string.need_model to Runnable { pickModel.launch(arrayOf("*/*")) }
            !s.notifications -> R.string.need_notifications to Runnable {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            !s.screen -> R.string.need_accessibility to Runnable {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            else -> R.string.need_apps to Runnable {
                startActivity(Intent(this, AppPickerActivity::class.java))
            }
        }
        statusLabel.setText(message)
        fixSetup.visibility = View.VISIBLE
        fixSetup.setOnClickListener { action.run() }
    }

    // ---- Memories --------------------------------------------------------

    private fun renderList() {
        val query = searchBox.text.toString().trim().lowercase()
        val all = MemoryStore.all(this).reversed()
        shown = if (query.isEmpty()) all
        else all.filter {
            it.text.lowercase().contains(query) || it.keywords.lowercase().contains(query)
        }

        adapter.clear()
        if (shown.isEmpty()) {
            adapter.add(getString(if (query.isEmpty()) R.string.no_memories else R.string.no_matches))
        } else {
            adapter.addAll(
                shown.map {
                    val pending = if (it.keywords.isBlank()) " *" else ""
                    "[${it.source}]$pending ${DateUtils.getRelativeTimeSpanString(it.id)}\n${it.text.take(110)}"
                }
            )
        }
        adapter.notifyDataSetChanged()
    }

    private fun showMemory(m: Memory) {
        val body = buildString {
            append(m.text.take(800))
            append("\n\n")
            when {
                m.keywords.isBlank() -> append(getString(R.string.mem_not_enriched))
                m.keywords == "-" -> append(getString(R.string.mem_enrich_failed))
                else -> append(getString(R.string.mem_words, m.keywords))
            }
        }
        AlertDialog.Builder(this)
            .setMessage(body)
            .setPositiveButton(R.string.edit) { _, _ -> editNote(m) }
            .setNeutralButton(R.string.delete) { _, _ ->
                MemoryStore.delete(this, m.id)
                refresh()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /**
     * One dialog for both new notes and corrections. A bad screen capture used
     * to be delete-and-start-again.
     */
    private fun editNote(existing: Memory?) {
        val input = EditText(this).apply {
            hint = getString(R.string.note_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setLines(5)
            setText(existing?.text.orEmpty())
        }
        AlertDialog.Builder(this)
            .setTitle(if (existing == null) R.string.add_note else R.string.edit_note)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val text = input.text.toString()
                // Replace rather than mutate: the edited text needs new related
                // words, and deleting first keeps the dedupe check honest.
                if (existing != null) MemoryStore.delete(this, existing.id)
                val ok = MemoryStore.add(this, existing?.source ?: "typed", text)
                if (ok) Enrich.runInBackground(this)
                Toast.makeText(
                    this,
                    if (ok) getString(R.string.remembered, text.length)
                    else getString(R.string.note_rejected),
                    Toast.LENGTH_SHORT
                ).show()
                refresh()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---- Model import ----------------------------------------------------

    private fun ensureNotificationPermission() {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

        if (granted) {
            if (Prefs.enabled(this)) Notifications.showControl(this)
        } else {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun displayName(uri: Uri): String =
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull() ?: "(unknown)"

    /**
     * Copies the chosen model into private storage so it survives a reboot
     * without a storage permission. The extension is preserved: handing a
     * .litertlm bundle to the runtime named .task would fail after a
     * multi-gigabyte copy.
     */
    private fun importModel(uri: Uri) {
        val chosenName = displayName(uri)
        val isLiteRtLm = chosenName.endsWith(".litertlm", ignoreCase = true)
        val dest = File(filesDir, if (isLiteRtLm) "model.litertlm" else "model.task")
        val stale = File(filesDir, if (isLiteRtLm) "model.task" else "model.litertlm")

        Toast.makeText(this, R.string.copying, Toast.LENGTH_LONG).show()
        Thread {
            runCatching { if (stale.exists()) stale.delete() }

            val result = runCatching {
                contentResolver.openInputStream(uri)!!.use { input ->
                    dest.outputStream().use { out -> input.copyTo(out, 1 shl 20) }
                }
            }
            runOnUiThread {
                if (result.isSuccess && dest.length() > 0) {
                    Prefs.setModelPath(this, dest.absolutePath)
                    Prefs.setModelName(this, chosenName)
                    Diag.log("model imported: $chosenName (${dest.length() / (1024 * 1024)} MB)")
                    LlmEngine.unload()
                    verifyModel()
                } else {
                    // Usually a full disk: the copy needs as much free space
                    // again as the file itself.
                    runCatching { dest.delete() }
                    Diag.log("model import FAILED: ${result.exceptionOrNull()?.message ?: "no space?"}")
                    Toast.makeText(this, R.string.copy_failed, Toast.LENGTH_LONG).show()
                }
                refresh()
            }
        }.start()
    }

    /**
     * Loads the model once and asks it for a single word.
     *
     * Worth the wait. A bad bundle -- a web build, a truncated download, a
     * context size the bundle cannot support -- used to announce itself days
     * later as silence during a real conversation. This turns that into an
     * answer now, while you still remember which file you picked.
     */
    private fun verifyModel() {
        val progress = AlertDialog.Builder(this)
            .setMessage(R.string.verifying)
            .setCancelable(false)
            .show()

        Thread {
            val started = System.currentTimeMillis()
            val result = runCatching { LlmEngine.generate(applicationContext, "Reply with one word: ready") }
            val ms = System.currentTimeMillis() - started
            runOnUiThread {
                runCatching { progress.dismiss() }
                val message = result.fold(
                    onSuccess = { getString(R.string.verify_ok, ms) },
                    onFailure = {
                        getString(
                            R.string.verify_failed,
                            "${it::class.java.simpleName}: ${it.message?.take(180) ?: "no detail"}"
                        )
                    }
                )
                Diag.log(
                    if (result.isSuccess) "model verified in ${ms}ms"
                    else "model verification FAILED: ${result.exceptionOrNull()?.message}"
                )
                AlertDialog.Builder(this)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
                refresh()
            }
        }.start()
    }

    private fun refresh() {
        applySetupState()

        val total = MemoryStore.all(this).size
        val pending = MemoryStore.withoutKeywords(this).size
        memoryCount.text = if (pending > 0) {
            getString(R.string.memory_count_pending, total, pending)
        } else {
            getString(R.string.memory_count, total)
        }

        renderList()
    }
}
