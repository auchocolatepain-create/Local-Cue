package dev.localcue

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.text.format.DateUtils
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ListView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var statusLabel: TextView
    private lateinit var modelLabel: TextView
    private lateinit var memoryCount: TextView
    private lateinit var memoryList: ListView

    private val pickModel = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) importModel(uri)
    }

    private val askNotifications = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted && Prefs.enabled(this)) Notifications.showControl(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusLabel = findViewById(R.id.statusLabel)
        modelLabel = findViewById(R.id.modelLabel)
        memoryCount = findViewById(R.id.memoryCount)
        memoryList = findViewById(R.id.memoryList)

        findViewById<Button>(R.id.btnModel).setOnClickListener {
            pickModel.launch(arrayOf("*/*"))
        }
        findViewById<Button>(R.id.btnNotifAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnApps).setOnClickListener {
            startActivity(Intent(this, AppPickerActivity::class.java))
        }
        findViewById<Button>(R.id.btnDiag).setOnClickListener {
            startActivity(Intent(this, DiagnosticsActivity::class.java))
        }
        findViewById<Button>(R.id.btnAddNote).setOnClickListener { promptForNote() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage(R.string.confirm_clear)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    MemoryStore.clear(this)
                    refresh()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }

        findViewById<CheckBox>(R.id.cbEnabled).apply {
            isChecked = Prefs.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, v ->
                Prefs.setEnabled(this@MainActivity, v)
                if (v) Notifications.showControl(this@MainActivity)
                else Notifications.hideControl(this@MainActivity)
            }
        }
        findViewById<CheckBox>(R.id.cbFallback).apply {
            isChecked = Prefs.fallbackCue(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setFallbackCue(this@MainActivity, v) }
        }
        findViewById<CheckBox>(R.id.cbLive).apply {
            isChecked = Prefs.liveScan(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setLiveScan(this@MainActivity, v) }
        }
        findViewById<CheckBox>(R.id.cbScreenOn).apply {
            isChecked = Prefs.onlyWhenScreenOn(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setOnlyWhenScreenOn(this@MainActivity, v) }
        }
        findViewById<Spinner>(R.id.spBackend).apply {
            adapter = ArrayAdapter.createFromResource(
                this@MainActivity, R.array.backends, android.R.layout.simple_spinner_item
            ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            setSelection(Prefs.backend(this@MainActivity))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    if (pos != Prefs.backend(this@MainActivity)) {
                        Prefs.setBackend(this@MainActivity, pos)
                    }
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }

        val cooldownLabel = findViewById<TextView>(R.id.cooldownLabel)
        findViewById<SeekBar>(R.id.sbCooldown).apply {
            max = 590
            progress = ((Prefs.cooldownMs(this@MainActivity) / 1000L).toInt() - 10)
                .coerceIn(0, 590)
            cooldownLabel.text = getString(R.string.cooldown, progress + 10)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    cooldownLabel.text = getString(R.string.cooldown, p + 10)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    Prefs.setCooldownSec(this@MainActivity, (s?.progress ?: 80) + 10)
                }
            })
        }

        // The adapter shows newest first, so the tapped position has to be
        // resolved against that same reversed list -- not against the raw store.
        memoryList.setOnItemLongClickListener { _, _, pos, _ ->
            val shown = MemoryStore.all(this).reversed()
            if (pos !in shown.indices) return@setOnItemLongClickListener true
            val m = shown[pos]
            AlertDialog.Builder(this)
                .setMessage(m.text.take(600))
                .setPositiveButton(R.string.delete) { _, _ ->
                    MemoryStore.delete(this, m.id)
                    refresh()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
            true
        }

        ensureNotificationPermission()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    /**
     * On Android 13+ a notification is silently dropped without this permission,
     * which would make both the cue and the "Remember this screen" button
     * invisible with no error anywhere.
     */
    private fun ensureNotificationPermission() {
        val granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

        if (granted) {
            if (Prefs.enabled(this)) Notifications.showControl(this)
        } else {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    /** Reads the human-readable filename behind a content:// URI. */
    private fun displayName(uri: Uri): String =
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull() ?: "(unknown)"

    /**
     * Copies the chosen model into the app's private storage, so it stays
     * readable after a reboot without needing any storage permission.
     *
     * The extension is PRESERVED. An earlier version always wrote "model.task",
     * which would have handed a .litertlm bundle to the runtime under a .task
     * name -- LiteRT-LM keys off the file, and a several-gigabyte copy failing
     * for a naming reason is an expensive way to find that out.
     */
    private fun importModel(uri: Uri) {
        val chosenName = displayName(uri)
        val isLiteRtLm = chosenName.endsWith(".litertlm", ignoreCase = true)
        val dest = File(filesDir, if (isLiteRtLm) "model.litertlm" else "model.task")
        val stale = File(filesDir, if (isLiteRtLm) "model.task" else "model.litertlm")

        Toast.makeText(this, R.string.copying, Toast.LENGTH_LONG).show()
        Thread {
            // A previous model of the other format would otherwise sit there
            // costing gigabytes forever.
            runCatching { if (stale.exists()) stale.delete() }

            val result = runCatching {
                contentResolver.openInputStream(uri)!!.use { input ->
                    dest.outputStream().use { out -> input.copyTo(out, 1 shl 20) }
                }
            }
            runOnUiThread {
                if (result.isSuccess && dest.length() > 0) {
                    Prefs.setModelPath(this, dest.absolutePath)
                    Prefs.setModelName(this, chosenName)
                    Diag.log("model imported: $chosenName (${dest.length() / (1024 * 1024)} MB)")
                    LlmEngine.unload()
                    Toast.makeText(this, R.string.copy_done, Toast.LENGTH_SHORT).show()
                } else {
                    // Usually this is a full disk: the copy needs as much free
                    // space again as the file itself.
                    runCatching { dest.delete() }
                    Diag.log("model import FAILED: ${result.exceptionOrNull()?.message ?: "no space?"}")
                    Toast.makeText(this, R.string.copy_failed, Toast.LENGTH_LONG).show()
                }
                refresh()
            }
        }.start()
    }

    /**
     * Until now the only ways in were capturing a screen or sharing text from
     * another app. Typing a note is the obvious case and it was missing.
     */
    private fun promptForNote() {
        val input = EditText(this).apply {
            hint = getString(R.string.note_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setLines(4)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.add_note)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val text = input.text.toString()
                val ok = MemoryStore.add(this, "typed", text)
                if (ok) Enrich.runInBackground(this)
                Toast.makeText(
                    this,
                    if (ok) getString(R.string.remembered, text.length)
                    else getString(R.string.note_rejected),
                    Toast.LENGTH_SHORT
                ).show()
                refresh()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /**
     * The buttons below open the relevant settings screens but never reported
     * whether anything was actually granted, which made a half-configured app
     * look identical to a working one.
     */
    private fun statusLine(): String {
        fun mark(ok: Boolean) = if (ok) "OK" else "NOT SET"
        val notif = Diag.notificationAccessGranted(this)
        val access = ScreenReaderService.instance != null
        val apps = Prefs.watchedApps(this).size
        val model = Prefs.modelPath(this)?.let { File(it).length() > 0 } == true
        return getString(
            R.string.status_line,
            mark(notif), mark(access), apps, mark(model)
        )
    }

    private fun refresh() {
        statusLabel.text = statusLine()
        val path = Prefs.modelPath(this)
        val f = path?.let { File(it) }
        modelLabel.text = if (f != null && f.canRead() && f.length() > 0) {
            getString(R.string.model_ok, f.length() / (1024 * 1024))
        } else {
            getString(R.string.model_none)
        }

        val all = MemoryStore.all(this)
        val items = all.reversed().map {
            "[${it.source}] ${DateUtils.getRelativeTimeSpanString(it.id)}\n${it.text.take(90)}"
        }
        memoryList.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            items.ifEmpty { listOf(getString(R.string.no_memories)) }
        )
        memoryCount.text = getString(R.string.memory_count, all.size)
    }
}
