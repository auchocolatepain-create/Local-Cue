package dev.localcue

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateUtils
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var modelLabel: TextView
    private lateinit var memoryList: ListView

    private val pickModel = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) importModel(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        modelLabel = findViewById(R.id.modelLabel)
        memoryList = findViewById(R.id.memoryList)

        findViewById<Button>(R.id.btnModel).setOnClickListener {
            pickModel.launch(arrayOf("*/*"))
        }
        findViewById<Button>(R.id.btnNotifAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnApps).setOnClickListener {
            startActivity(Intent(this, AppPickerActivity::class.java))
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage(R.string.confirm_clear)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    MemoryStore.clear(this); refresh()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }

        findViewById<CheckBox>(R.id.cbEnabled).apply {
            isChecked = Prefs.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, v ->
                Prefs.setEnabled(this@MainActivity, v)
                if (v) Notifications.showControl(this@MainActivity)
                else Notifications.hideControl(this@MainActivity)
            }
        }
        findViewById<CheckBox>(R.id.cbScreenOn).apply {
            isChecked = Prefs.onlyWhenScreenOn(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setOnlyWhenScreenOn(this@MainActivity, v) }
        }
        findViewById<CheckBox>(R.id.cbGpu).apply {
            isChecked = Prefs.useGpu(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setUseGpu(this@MainActivity, v) }
        }

        val cooldownLabel = findViewById<TextView>(R.id.cooldownLabel)
        findViewById<SeekBar>(R.id.sbCooldown).apply {
            max = 590
            progress = (Prefs.cooldownMs(this@MainActivity) / 1000).toInt() - 10
            cooldownLabel.text = getString(R.string.cooldown, progress + 10)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    cooldownLabel.text = getString(R.string.cooldown, p + 10)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    Prefs.setCooldownSec(this@MainActivity, (s?.progress ?: 80) + 10)
                }
            })
        }

        memoryList.setOnItemLongClickListener { _, _, pos, _ ->
            val m = MemoryStore.all(this)[pos]
            AlertDialog.Builder(this)
                .setMessage(m.text.take(600))
                .setPositiveButton(R.string.delete) { _, _ ->
                    MemoryStore.delete(this, m.id); refresh()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
            true
        }

        if (Prefs.enabled(this)) Notifications.showControl(this)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    /**
     * Copies the chosen .task file into the app's private storage. This keeps
     * the model readable after a reboot without needing any storage permission.
     */
    private fun importModel(uri: Uri) {
        val dest = File(filesDir, "model.task")
        Toast.makeText(this, R.string.copying, Toast.LENGTH_LONG).show()
        Thread {
            val ok = runCatching {
                contentResolver.openInputStream(uri)!!.use { input ->
                    dest.outputStream().use { out -> input.copyTo(out, 1 shl 20) }
                }
            }.isSuccess
            runOnUiThread {
                if (ok) {
                    Prefs.setModelPath(this, dest.absolutePath)
                    LlmEngine.unload()
                } else {
                    Toast.makeText(this, R.string.copy_failed, Toast.LENGTH_LONG).show()
                }
                refresh()
            }
        }.start()
    }

    private fun refresh() {
        val path = Prefs.modelPath(this)
        val f = path?.let { File(it) }
        modelLabel.text = if (f != null && f.canRead()) {
            getString(R.string.model_ok, f.length() / (1024 * 1024))
        } else {
            getString(R.string.model_none)
        }

        val items = MemoryStore.all(this).reversed().map {
            val when_ = DateUtils.getRelativeTimeSpanString(it.id)
            "[${it.source}] $when_\n${it.text.take(90)}"
        }
        memoryList.adapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, items.ifEmpty {
                listOf(getString(R.string.no_memories))
            })
        findViewById<View>(R.id.memoryCount).let {
            (it as TextView).text = getString(R.string.memory_count, MemoryStore.all(this).size)
        }
    }
}
