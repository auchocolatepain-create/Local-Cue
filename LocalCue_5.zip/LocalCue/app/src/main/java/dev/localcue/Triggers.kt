package dev.localcue

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.quicksettings.TileService
import android.widget.Toast
import androidx.core.app.NotificationCompat

// ---------------------------------------------------------------------------
// Quick Settings tile: pull down the shade, tap once, screen is remembered.
// ---------------------------------------------------------------------------
class CaptureTileService : TileService() {
    override fun onClick() {
        super.onClick()
        val svc = ScreenReaderService.instance
        if (svc == null) {
            Toast.makeText(this, R.string.enable_accessibility, Toast.LENGTH_LONG).show()
            return
        }
        // The shade must be collapsed first, otherwise we would read the shade
        // itself. The accessibility service can do that directly, which avoids
        // startActivityAndCollapse() entirely -- that API only accepts an
        // activity PendingIntent on API 34+ and throws on a broadcast one.
        svc.dismissShadeAndCapture()
    }
}

// ---------------------------------------------------------------------------
// Handles the notification buttons and the delayed tile capture.
// ---------------------------------------------------------------------------
class ActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_CAPTURE = "dev.localcue.CAPTURE"
        const val ACTION_COPY = "dev.localcue.COPY"
        const val EXTRA_TEXT = "text"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_CAPTURE -> {
                val svc = ScreenReaderService.instance
                if (svc == null) {
                    Toast.makeText(context, R.string.enable_accessibility, Toast.LENGTH_LONG).show()
                } else {
                    // Collapses the shade, then reads the app underneath.
                    svc.dismissShadeAndCapture()
                }
            }

            ACTION_COPY -> {
                val text = intent.getStringExtra(EXTRA_TEXT) ?: return
                val cm = context.getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("cue", text))
                context.getSystemService(NotificationManager::class.java)
                    .cancel(Notifications.ID_CUE)
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Share target. This is how your notes app feeds the memory:
// select a note -> Share -> LocalCue. Also appears in the text-selection menu.
// ---------------------------------------------------------------------------
class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT)
            ?: intent?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
        if (text.isNullOrBlank()) {
            Toast.makeText(this, R.string.nothing_to_read, Toast.LENGTH_SHORT).show()
        } else {
            val ok = MemoryStore.add(this, "note", text)
            if (ok) Enrich.runInBackground(this)
            Toast.makeText(
                this,
                if (ok) getString(R.string.remembered, text.length) else getString(R.string.duplicate),
                Toast.LENGTH_SHORT
            ).show()
        }
        finish()
    }
}

// ---------------------------------------------------------------------------
object Notifications {

    const val CH_CUE = "cue"
    const val CH_CONTROL = "control"
    const val ID_CUE = 1001
    const val ID_CONTROL = 1002
    const val ID_PROBLEM = 1003

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 3,
        Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE
    )

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_CUE, ctx.getString(R.string.ch_cue), NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_CONTROL, ctx.getString(R.string.ch_control), NotificationManager.IMPORTANCE_MIN)
        )
    }

    /** The persistent "Remember this screen" button that lives in your shade. */
    fun showControl(ctx: Context) {
        val capture = PendingIntent.getBroadcast(
            ctx, 1,
            Intent(ctx, ActionReceiver::class.java).setAction(ActionReceiver.ACTION_CAPTURE),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CH_CONTROL)
            .setSmallIcon(R.drawable.ic_cue)
            .setContentTitle(ctx.getString(R.string.app_name))
            .setContentText(ctx.getString(R.string.tap_to_remember))
            .setOngoing(true)
            .setShowWhen(false)
            .setContentIntent(openApp(ctx))
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(R.drawable.ic_cue, ctx.getString(R.string.remember_screen), capture)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_CONTROL, n)
    }

    fun hideControl(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID_CONTROL)
    }

    fun showCue(ctx: Context, text: String) {
        val copy = PendingIntent.getBroadcast(
            ctx, 2,
            Intent(ctx, ActionReceiver::class.java)
                .setAction(ActionReceiver.ACTION_COPY)
                .putExtra(ActionReceiver.EXTRA_TEXT, text),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CH_CUE)
            .setSmallIcon(R.drawable.ic_cue)
            .setContentTitle(ctx.getString(R.string.cue_title))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(R.drawable.ic_cue, ctx.getString(R.string.copy), copy)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_CUE, n)
    }

    fun showProblem(ctx: Context, text: String) {
        val n = NotificationCompat.Builder(ctx, CH_CONTROL)
            .setSmallIcon(R.drawable.ic_cue)
            .setContentTitle(ctx.getString(R.string.app_name))
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_PROBLEM, n)
    }
}
