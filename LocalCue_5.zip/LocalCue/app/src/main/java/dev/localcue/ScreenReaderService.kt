package dev.localcue

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Reads the text of the current screen -- but ONLY when you ask.
 *
 * onAccessibilityEvent is deliberately empty: the service never reacts to
 * anything you do. It exists purely so that captureToMemory() has permission
 * to walk the view tree at the moment you tap the tile or the notification
 * button. Nothing is captured in between.
 */
class ScreenReaderService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenReaderService? = null

        /** Delay after collapsing the shade before the screen underneath is read. */
        private const val SHADE_COLLAPSE_MS = 450L
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty. This service never reacts to screen activity.
    }

    override fun onInterrupt() {}

    private fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collect(root, sb, 0)
        return sb.toString().trim()
    }

    private fun collect(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 40 || sb.length > 8000) return
        node.text?.toString()?.trim()?.let { if (it.isNotEmpty()) sb.append(it).append('\n') }
        node.contentDescription?.toString()?.trim()?.let {
            if (it.length > 3) sb.append(it).append('\n')
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), sb, depth + 1)
    }

    /**
     * Collapses the notification shade, waits for the animation, then reads the
     * app underneath. Both the Quick Settings tile and the notification button
     * come through here, so there is exactly one code path.
     */
    fun dismissShadeAndCapture() {
        runCatching { performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE) }
        main.postDelayed({ captureToMemory() }, SHADE_COLLAPSE_MS)
    }

    fun captureToMemory() {
        val text = readScreen()
        if (text.length < 15) {
            Toast.makeText(this, R.string.nothing_to_read, Toast.LENGTH_SHORT).show()
            return
        }
        val added = MemoryStore.add(this, "screen", text)
        Toast.makeText(
            this,
            if (added) getString(R.string.remembered, text.length) else getString(R.string.duplicate),
            Toast.LENGTH_SHORT
        ).show()
    }
}
