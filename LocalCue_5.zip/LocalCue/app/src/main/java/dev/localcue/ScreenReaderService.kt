package dev.localcue

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Reads the text of the current screen -- but ONLY when you ask.
 *
 * onAccessibilityEvent is deliberately empty. The service receives no event
 * types (see res/xml/accessibility_config.xml, which requests none), so it is
 * not watching you as you use your phone. It exists purely so that captureNow()
 * has permission to walk the view tree at the moment you tap the tile or the
 * notification button. Nothing is captured in between.
 */
class ScreenReaderService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenReaderService? = null

        fun capture(): String? = instance?.readScreen()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty. This service never reacts to screen activity.
    }

    override fun onInterrupt() {}

    private fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collect(root, sb, 0)
        runCatching { root.recycle() }
        return sb.toString().trim()
    }

    private fun collect(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 40 || sb.length > 8000) return
        node.text?.toString()?.trim()?.let { if (it.isNotEmpty()) sb.append(it).append("\n") }
        node.contentDescription?.toString()?.trim()?.let {
            if (it.isNotEmpty() && it.length > 3) sb.append(it).append("\n")
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), sb, depth + 1)
    }

    fun captureToMemory() {
        val text = readScreen()
        if (text.length < 15) {
            Toast.makeText(this, R.string.nothing_to_read, Toast.LENGTH_SHORT).show()
            return
        }
        val added = MemoryStore.add(this, "screen", text)
        Toast.makeText(
            this,
            if (added) getString(R.string.remembered, text.length) else getString(R.string.duplicate),
            Toast.LENGTH_SHORT
        ).show()
    }
}
