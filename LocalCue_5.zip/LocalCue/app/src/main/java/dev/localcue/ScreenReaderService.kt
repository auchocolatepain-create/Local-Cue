package dev.localcue

import android.accessibilityservice.AccessibilityService
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Reads the screen. Two modes, both under your control.
 *
 * MANUAL  -- the tile and the notification button. Works in any app.
 * LIVE    -- while one of your ticked messaging apps is in the foreground,
 *            the conversation on screen is watched and a cue can fire without
 *            waiting for a notification. Toggle in the main screen.
 *
 * Live mode is the expensive one, so it is fenced in hard:
 *
 *  1. Runtime package filter. serviceInfo.packageNames is set to exactly your
 *     ticked apps, so Android does not even deliver events from anything else.
 *     This is the single biggest saving -- the callback below never runs while
 *     you are in other apps.
 *  2. Debounce. Content events arrive on every keystroke and animation frame;
 *     nothing happens until the screen has been quiet for SCAN_DEBOUNCE_MS.
 *  3. Tail hashing. Only the last TAIL_CHARS of the screen are considered, and
 *     if that text has not changed since the last scan, the scan stops there.
 *  4. The keyword prefilter still runs before the model is ever woken.
 *  5. All the existing gates still apply: battery saver, battery floor,
 *     screen off, and the per-app cooldown.
 *
 * Nothing read in live mode is written to disk. It is scored, optionally sent
 * to the local model, and dropped.
 */
class ScreenReaderService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenReaderService? = null

        private const val SHADE_COLLAPSE_MS = 450L
        private const val SCAN_DEBOUNCE_MS = 1200L
        private const val TAIL_CHARS = 500
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lastCueAt = HashMap<String, Long>()

    private var pendingPkg: String? = null

    // Per package. A single shared hash meant switching between two watched
    // apps could make the second one look "unchanged" and skip its scan.
    private val lastTailHash = HashMap<String, Int>()
    private val scanTask = Runnable { scanNow() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        applyWatchedPackages()
        Diag.log("accessibility service connected")
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacks(scanTask)
        super.onDestroy()
    }

    /**
     * Narrows event delivery to the ticked apps. Called on connect and again
     * whenever the app picker changes, so the filter never goes stale.
     *
     * Note this only filters *events*. rootInActiveWindow is unaffected, so
     * manual capture still works in every app, including your notes app.
     */
    fun applyWatchedPackages() {
        val info = serviceInfo ?: return
        val apps = Prefs.watchedApps(this)
        info.packageNames =
            if (apps.isEmpty()) arrayOf("$packageName.nothing") else apps.toTypedArray()
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        info.notificationTimeout = 500
        serviceInfo = info
        Diag.log("live scan armed for ${apps.size} app(s)")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!Prefs.liveScan(this)) return
        if (!Prefs.enabled(this)) return

        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (!Prefs.watchedApps(this).contains(pkg)) return

        pendingPkg = pkg
        main.removeCallbacks(scanTask)
        main.postDelayed(scanTask, SCAN_DEBOUNCE_MS)
    }

    override fun onInterrupt() {}

    // ---- Live scanning ---------------------------------------------------

    private fun scanNow() {
        val pkg = pendingPkg ?: return

        val pm = getSystemService(PowerManager::class.java)
        if (pm?.isPowerSaveMode == true) return
        if (pm?.isInteractive == false) return

        val bm = getSystemService(BatteryManager::class.java)
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        if (level < Prefs.minBattery(this)) return

        val now = System.currentTimeMillis()
        if (now - (lastCueAt[pkg] ?: 0L) < Prefs.cooldownMs(this)) return

        val readStartedAt = System.currentTimeMillis()
        val screen = readScreen(expected = pkg)
        val readMs = System.currentTimeMillis() - readStartedAt
        if (readMs > 250) Diag.log("$pkg live: screen read took ${readMs}ms")
        if (screen.length < 20) return

        // The newest messages sit at the bottom of a conversation.
        val tail = screen.takeLast(TAIL_CHARS)
        val hash = tail.hashCode()
        if (lastTailHash[pkg] == hash) return

        val hits = MemoryStore.relevant(this, tail)
        if (hits.isEmpty()) {
            // Safe to remember: an unchanged screen will not start matching.
            lastTailHash[pkg] = hash
            Diag.log("$pkg live: nothing in memory overlaps the screen")
            return
        }

        if (LlmEngine.isBusy()) {
            // Deliberately do NOT record the hash here. Marking this screen as
            // "seen" while dropping the work meant the scan was never retried
            // once the model freed up -- the cue was lost silently.
            Diag.log("$pkg live: model still busy, will retry this screen")
            return
        }

        lastTailHash[pkg] = hash
        lastCueAt[pkg] = now
        Diag.log("$pkg live: ${hits.size} memory match(es), waking model")

        scope.launch {
            runCatching {
                val prompt = Diag.buildPrompt(hits, tail, "Conversation on screen")
                val answer = LlmEngine.generate(applicationContext, prompt)
                Cue.deliver(applicationContext, answer, hits, "live")
            }.onFailure {
                if (it is LlmEngine.Busy) {
                    Diag.log("live: model busy, dropped")
                    return@onFailure
                }
                Diag.log("live INFERENCE FAILED: ${it::class.java.simpleName}: ${it.message}")
                if (it is LlmEngine.ModelMissing) {
                    Notifications.showProblem(applicationContext, getString(R.string.no_model))
                } else {
                    Notifications.showProblem(
                        applicationContext,
                        getString(R.string.model_error, it.message?.take(100) ?: "unknown")
                    )
                }
            }
        }
    }

    // ---- Reading ---------------------------------------------------------

    /**
     * @param expected when set, the read is abandoned unless this package is
     *   still in the foreground.
     *
     * This matters more than it looks. A live scan runs SCAN_DEBOUNCE_MS after
     * the event that triggered it, and rootInActiveWindow returns whatever is
     * in front at that moment. Switch from a watched messenger to your banking
     * app inside that window and the old code read the banking app, scored it
     * against memory, and could have sent it to the model -- an app you never
     * ticked. Manual capture passes null, because there it is you asking.
     */
    private fun readScreen(expected: String? = null): String {
        val root = rootInActiveWindow ?: return ""
        val nowShowing = root.packageName?.toString()
        if (expected != null && nowShowing != expected) {
            Diag.log("live: foreground moved to $nowShowing, scan abandoned")
            return ""
        }
        val sb = StringBuilder()
        collect(root, sb, 0)
        return tidy(sb.toString())
    }

    /**
     * A chat screen is mostly furniture: timestamps, "online", "Type a message",
     * the same contact name repeated. All of it was being scored against memory
     * and pasted into the prompt, which both caused false matches and wasted
     * scarce context on a small model.
     *
     * Conservative on purpose -- it only removes things that cannot be message
     * content.
     */
    private fun tidy(raw: String): String {
        val timeOnly = Regex("^\\d{1,2}[:.]\\d{2}(\\s?[AaPp][Mm])?$")
        val out = ArrayList<String>()
        var previous = ""
        for (line in raw.lineSequence()) {
            val t = line.trim()
            if (t.length < 2) continue
            if (timeOnly.matches(t)) continue
            if (t == previous) continue          // collapse repeats
            previous = t
            out.add(t)
        }
        return out.joinToString("\n").trim()
    }

    private fun collect(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 40 || sb.length > 8000) return
        node.text?.toString()?.trim()?.let { if (it.isNotEmpty()) sb.append(it).append('\n') }
        node.contentDescription?.toString()?.trim()?.let {
            if (it.length > 3) sb.append(it).append('\n')
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), sb, depth + 1)
    }

    // ---- Manual capture --------------------------------------------------

    /**
     * Collapses the notification shade, waits for the animation, then reads the
     * app underneath. Both the tile and the notification button come through
     * here, so there is exactly one code path.
     */
    fun dismissShadeAndCapture() {
        runCatching { performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE) }
        main.postDelayed({ captureToMemory() }, SHADE_COLLAPSE_MS)
    }

    /**
     * "Cue me about this screen", from the notification button. Deliberately
     * ignores the cooldown and the unchanged-screen check: you asked, so the
     * gates that exist to stop UNPROMPTED work do not apply.
     */
    fun cueNowFromScreen() {
        val text = readScreen()
        if (text.length < 20) {
            Toast.makeText(this, R.string.nothing_to_read, Toast.LENGTH_SHORT).show()
            return
        }
        val tail = text.takeLast(TAIL_CHARS)
        val hits = MemoryStore.relevant(this, tail)
        if (hits.isEmpty()) {
            Toast.makeText(this, R.string.no_match_here, Toast.LENGTH_LONG).show()
            Diag.log("manual cue: nothing in memory overlaps this screen")
            return
        }
        if (LlmEngine.isBusy()) {
            Toast.makeText(this, R.string.model_busy, Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, R.string.thinking, Toast.LENGTH_SHORT).show()
        Diag.log("manual cue requested, ${hits.size} match(es)")
        scope.launch {
            runCatching {
                val prompt = Diag.buildPrompt(hits, tail, "Conversation on screen")
                Cue.deliver(applicationContext, LlmEngine.generate(applicationContext, prompt), hits, "manual")
            }.onFailure {
                Diag.log("manual cue FAILED: ${it::class.java.simpleName}: ${it.message}")
                Notifications.showProblem(
                    applicationContext,
                    getString(R.string.model_error, it.message?.take(100) ?: "unknown")
                )
            }
        }
    }

    fun dismissShadeAndCueNow() {
        runCatching { performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE) }
        main.postDelayed({ cueNowFromScreen() }, SHADE_COLLAPSE_MS)
    }

    fun captureToMemory() {
        val text = readScreen()
        if (text.length < 15) {
            Toast.makeText(this, R.string.nothing_to_read, Toast.LENGTH_SHORT).show()
            return
        }
        val added = MemoryStore.add(this, "screen", text)
        if (added) Enrich.runInBackground(this)
        Toast.makeText(
            this,
            if (added) getString(R.string.remembered, text.length) else getString(R.string.duplicate),
            Toast.LENGTH_SHORT
        ).show()
    }
}
