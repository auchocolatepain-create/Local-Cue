package dev.localcue

import android.accessibilityservice.AccessibilityService
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Reads the screen. Two modes, both under your control.
 *
 * MANUAL  -- the tile and the notification button. Works in any app.
 * LIVE    -- while one of your ticked messaging apps is in the foreground,
 *            the conversation on screen is watched and a cue can fire without
 *            waiting for a notification. Toggle in the main screen.
 *
 * Live mode is the expensive one, so it is fenced in hard:
 *
 *  1. Runtime package filter. serviceInfo.packageNames is set to exactly your
 *     ticked apps, so Android does not even deliver events from anything else.
 *     This is the single biggest saving -- the callback below never runs while
 *     you are in other apps.
 *  2. Debounce. Content events arrive on every keystroke and animation frame;
 *     nothing happens until the screen has been quiet for SCAN_DEBOUNCE_MS.
 *  3. Tail hashing. Only the last TAIL_CHARS of the screen are considered, and
 *     if that text has not changed since the last scan, the scan stops there.
 *  4. The keyword prefilter still runs before the model is ever woken.
 *  5. All the existing gates still apply: battery saver, battery floor,
 *     screen off, and the per-app cooldown.
 *
 * Nothing read in live mode is written to disk. It is scored, optionally sent
 * to the local model, and dropped.
 */
class ScreenReaderService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenReaderService? = null

        private const val SHADE_COLLAPSE_MS = 450L
        private const val SCAN_DEBOUNCE_MS = 1200L
        private const val TAIL_CHARS = 500
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lastCueAt = HashMap<String, Long>()

    private var pendingPkg: String? = null
    private var lastTailHash = 0
    private val scanTask = Runnable { scanNow() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        applyWatchedPackages()
        Diag.log("accessibility service connected")
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacks(scanTask)
        super.onDestroy()
    }

    /**
     * Narrows event delivery to the ticked apps. Called on connect and again
     * whenever the app picker changes, so the filter never goes stale.
     *
     * Note this only filters *events*. rootInActiveWindow is unaffected, so
     * manual capture still works in every app, including your notes app.
     */
    fun applyWatchedPackages() {
        val info = serviceInfo ?: return
        val apps = Prefs.watchedApps(this)
        info.packageNames =
            if (apps.isEmpty()) arrayOf("$packageName.nothing") else apps.toTypedArray()
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        info.notificationTimeout = 500
        serviceInfo = info
        Diag.log("live scan armed for ${apps.size} app(s)")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!Prefs.liveScan(this)) return
        if (!Prefs.enabled(this)) return

        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (!Prefs.watchedApps(this).contains(pkg)) return

        pendingPkg = pkg
        main.removeCallbacks(scanTask)
        main.postDelayed(scanTask, SCAN_DEBOUNCE_MS)
    }

    override fun onInterrupt() {}

    // ---- Live scanning ---------------------------------------------------

    private fun scanNow() {
        val pkg = pendingPkg ?: return

        val pm = getSystemService(PowerManager::class.java)
        if (pm?.isPowerSaveMode == true) return
        if (pm?.isInteractive == false) return

        val bm = getSystemService(BatteryManager::class.java)
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        if (level < Prefs.minBattery(this)) return

        val now = System.currentTimeMillis()
        if (now - (lastCueAt[pkg] ?: 0L) < Prefs.cooldownMs(this)) return

        val screen = readScreen()
        if (screen.length < 20) return

        // The newest messages sit at the bottom of a conversation.
        val tail = screen.takeLast(TAIL_CHARS)
        val hash = tail.hashCode()
        if (hash == lastTailHash) return
        lastTailHash = hash

        val hits = MemoryStore.relevant(this, tail)
        if (hits.isEmpty()) {
            Diag.log("$pkg live: nothing in memory overlaps the screen")
            return
        }

        if (LlmEngine.isBusy()) {
            // Do NOT consume the cooldown for work we are about to drop.
            Diag.log("$pkg live: model still busy, skipping this screen")
            return
        }

        lastCueAt[pkg] = now
        Diag.log("$pkg live: ${hits.size} memory match(es), waking model")

        scope.launch {
            runCatching {
                val prompt = Diag.buildPrompt(hits, tail, "Conversation on screen")
                val answer = LlmEngine.generate(applicationContext, prompt)
                Cue.deliver(applicationContext, answer, hits, "live")
            }.onFailure {
                if (it is LlmEngine.Busy) {
                    Diag.log("live: model busy, dropped")
                    return@onFailure
                }
                Diag.log("live INFERENCE FAILED: ${it::class.java.simpleName}: ${it.message}")
                if (it is LlmEngine.ModelMissing) {
                    Notifications.showProblem(applicationContext, getString(R.string.no_model))
                } else {
                    Notifications.showProblem(
                        applicationContext,
                        getString(R.string.model_error, it.message?.take(100) ?: "unknown")
                    )
                }
            }
        }
    }

    // ---- Reading ---------------------------------------------------------

    private fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collect(root, sb, 0)
        return sb.toString().trim()
    }

    private fun collect(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 40 || sb.length > 8000) return
        node.text?.toString()?.trim()?.let { if (it.isNotEmpty()) sb.append(it).append('\n') }
        node.contentDescription?.toString()?.trim()?.let {
            if (it.length > 3) sb.append(it).append('\n')
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), sb, depth + 1)
    }

    // ---- Manual capture --------------------------------------------------

    /**
     * Collapses the notification shade, waits for the animation, then reads the
     * app underneath. Both the tile and the notification button come through
     * here, so there is exactly one code path.
     */
    fun dismissShadeAndCapture() {
        runCatching { performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE) }
        main.postDelayed({ captureToMemory() }, SHADE_COLLAPSE_MS)
    }

    fun captureToMemory() {
        val text = readScreen()
        if (text.length < 15) {
            Toast.makeText(this, R.string.nothing_to_read, Toast.LENGTH_SHORT).show()
            return
        }
        val added = MemoryStore.add(this, "screen", text)
        if (added) Enrich.runInBackground(this)
        Toast.makeText(
            this,
            if (added) getString(R.string.remembered, text.length) else getString(R.string.duplicate),
            Toast.LENGTH_SHORT
        ).show()
    }
}
