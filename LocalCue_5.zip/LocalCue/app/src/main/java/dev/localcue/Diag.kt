package dev.localcue

import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Everything needed to answer "why did no cue appear?" without a cable.
 *
 * Two halves:
 *  - log()/dump(): a rolling record of every notification the listener saw and
 *    the exact gate that stopped it. This is what proves whether a message
 *    reached the app at all.
 *  - selfTest(): runs the full pipeline against a message you type, so the
 *    prefilter and the model can be exercised without waiting for anyone to
 *    text you.
 *
 * Stays in memory only. Nothing here is written to disk.
 */
object Diag {

    private const val MAX_LINES = 80
    private val lines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun log(message: String) {
        lines.addLast("${clock.format(Date())}  $message")
        while (lines.size > MAX_LINES) lines.removeFirst()
    }

    @Synchronized
    fun dump(): String =
        if (lines.isEmpty()) {
            "No notifications seen yet.\n\n" +
                "If this stays empty while messages arrive, the listener is not " +
                "running: check notification access, then reboot."
        } else {
            // Newest first, and say so: entries above a settings change are the
            // only ones that reflect it, which is easy to misread otherwise.
            "----- NEWEST FIRST (${lines.size} entries) -----\n" +
                lines.reversed().joinToString("\n") +
                "\n----- OLDEST -----"
        }

    private val seenOnce = HashSet<String>()

    /** For high-frequency noise: logs the first occurrence of a key only. */
    @Synchronized
    fun logOnce(key: String, message: String) {
        if (seenOnce.add(key)) log(message)
    }

    @Synchronized
    fun clear() {
        lines.clear()
        seenOnce.clear()
    }

    fun notificationAccessGranted(ctx: Context): Boolean {
        val enabled = Settings.Secure.getString(
            ctx.contentResolver, "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(ctx.packageName)
    }

    /** Shared by the listener and the self test so both exercise the same prompt. */
    fun buildPrompt(
        hits: List<Memory>,
        message: String,
        label: String = "Incoming message"
    ): String {
        // Prefill is the slow half of CPU inference, so keep the prompt small.
        val notes = hits.take(3).joinToString("\n") { "- ${it.text.take(200)}" }
        return buildString {
            append("You are a private assistant with access to notes the user saved.\n\n")
            append("Saved notes:\n").append(notes).append("\n\n")
            append(label).append(": \"").append(message.takeLast(500)).append("\"\n\n")
            append("If one of the saved notes directly answers or helps with this ")
            append("message, reply with that fact in under 15 words. ")
            append("If not, reply with exactly: NOTHING")
        }
    }

    /**
     * Walks every gate in the same order the listener does and reports where a
     * real message would have died. Call this off the main thread: the last
     * stage runs actual inference and can take several seconds.
     */
    fun selfTest(ctx: Context, message: String): String {
        val sb = StringBuilder()
        fun line(s: String = "") = sb.append(s).append('\n')

        line("=== Permissions ===")
        line("Cues enabled       : ${Prefs.enabled(ctx)}")
        line("Notification access: ${notificationAccessGranted(ctx)}")
        line("Accessibility svc  : ${ScreenReaderService.instance != null}")
        line("Live screen scan   : ${Prefs.liveScan(ctx)}")

        val watched = Prefs.watchedApps(ctx)
        line()
        line("=== Watched apps (${watched.size}) ===")
        if (watched.isEmpty()) {
            line("NONE TICKED. No notification can ever trigger a cue.")
        } else {
            watched.sorted().forEach { line("  $it") }
        }

        line()
        line("=== Battery gates ===")
        val pm = ctx.getSystemService(PowerManager::class.java)
        line("Battery saver on : ${pm?.isPowerSaveMode}   (blocks cues if true)")
        line("Screen-on gate   : ${Prefs.onlyWhenScreenOn(ctx)}   (screen currently on: ${pm?.isInteractive})")
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        line("Battery level    : $level%   (minimum ${Prefs.minBattery(ctx)}%)")
        line("Cooldown         : ${Prefs.cooldownMs(ctx) / 1000}s per app")

        val all = MemoryStore.all(ctx)
        line()
        line("=== Memory (${all.size} entries) ===")
        all.takeLast(5).forEach { line("  [${it.source}] ${it.text.take(70)}") }

        line()
        line("=== Prefilter ===")
        line("Test message: \"$message\"")
        if (message.length < 12) {
            line("NOTE: a real notification body under 12 characters is dropped.")
        }
        val hits = MemoryStore.relevant(ctx, message)
        if (hits.isEmpty()) {
            line()
            line("NO MATCH -> the model would never be woken.")
            line("Matching is whole-word only and ignores words under 4 letters,")
            line("so \"bottles\" does not match \"bottle\".")
            return sb.toString()
        }
        line("Matched ${hits.size} entr${if (hits.size == 1) "y" else "ies"}:")
        hits.forEach { line("  [${it.source}] ${it.text.take(70)}") }

        line()
        line("=== Model ===")
        val path = Prefs.modelPath(ctx)
        val file = path?.let { File(it) }
        line("File: ${Prefs.modelName(ctx).ifEmpty { "(imported before names were recorded)" }}")
        line("Path: ${path ?: "(none selected)"}")
        line("Size: " + if (file != null && file.exists()) "${file.length() / (1024 * 1024)} MB" else "MISSING")
        line("Backend requested: ${if (Prefs.useGpu(ctx)) "GPU" else "CPU"}")

        line()
        line("=== Inference ===")
        val startedAt = System.currentTimeMillis()
        val outcome = runCatching { LlmEngine.generate(ctx, buildPrompt(hits, message)) }
        val elapsed = System.currentTimeMillis() - startedAt

        outcome.onSuccess { raw ->
            line("Completed in ${elapsed}ms")
            line("Raw output: \"$raw\"")
            val cleaned = raw.trim().trim('"', '.', ' ')
            val suppressed = cleaned.isEmpty() ||
                cleaned.equals("NOTHING", ignoreCase = true) ||
                cleaned.contains("NOTHING", ignoreCase = true) ||
                cleaned.length >= 200
            line()
            line(
                if (suppressed) "SUPPRESSED - the model declined, or the reply was too long."
                else "THIS WOULD HAVE BEEN SHOWN AS A CUE."
            )
        }.onFailure { e ->
            line("Failed after ${elapsed}ms")
            line("${e::class.java.simpleName}: ${e.message ?: "(no message)"}")
            line()
            line("A failure here means the .task bundle is not a valid MediaPipe")
            line("Android bundle. The usual causes are a web/WASM build, a")
            line("truncated download, or a context length below the app's 640.")
        }
        return sb.toString()
    }
}
