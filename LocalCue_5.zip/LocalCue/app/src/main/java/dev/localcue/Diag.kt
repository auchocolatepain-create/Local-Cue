package dev.localcue

import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Everything needed to answer "why did no cue appear?" without a cable.
 *
 * Two halves:
 *  - log()/dump(): a rolling record of every notification the listener saw and
 *    the exact gate that stopped it. This is what proves whether a message
 *    reached the app at all.
 *  - selfTest(): runs the full pipeline against a message you type, so the
 *    prefilter and the model can be exercised without waiting for anyone to
 *    text you.
 *
 * The log is mirrored to a small private file so it SURVIVES a restart. A
 * crash or a force-stop used to erase exactly the evidence needed to explain
 * it. Capped at MAX_LINES and written at most once every few seconds, so the
 * cost is negligible. Private storage, same sandbox as memory.json.
 */
object Diag {

    private const val MAX_LINES = 120
    private const val FILE = "diag.log"
    private const val FLUSH_EVERY_MS = 4000L

    private val lines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Volatile private var appContext: Context? = null
    private var loaded = false
    private var lastFlushAt = 0L

    /** Called once from CueApp so services and activities share one log. */
    fun attach(ctx: Context) {
        appContext = ctx.applicationContext
        loadIfNeeded()
    }

    @Synchronized
    private fun loadIfNeeded() {
        if (loaded) return
        loaded = true
        val ctx = appContext ?: return
        runCatching {
            val f = File(ctx.filesDir, FILE)
            if (f.exists()) {
                f.readLines().takeLast(MAX_LINES).forEach { lines.addLast(it) }
                lines.addLast("${clock.format(Date())}  --- app restarted ---")
            }
        }
    }

    @Synchronized
    private fun flush(force: Boolean) {
        val ctx = appContext ?: return
        val now = System.currentTimeMillis()
        if (!force && now - lastFlushAt < FLUSH_EVERY_MS) return
        lastFlushAt = now
        runCatching { File(ctx.filesDir, FILE).writeText(lines.joinToString("\n")) }
    }

    @Synchronized
    fun log(message: String) {
        loadIfNeeded()
        lines.addLast("${clock.format(Date())}  $message")
        while (lines.size > MAX_LINES) lines.removeFirst()
        flush(force = false)
    }

    @Synchronized
    fun dump(): String =
        if (lines.isEmpty()) {
            "No notifications seen yet.\n\n" +
                "If this stays empty while messages arrive, the listener is not " +
                "running: check notification access, then reboot."
        } else {
            // Newest first, and say so: entries above a settings change are the
            // only ones that reflect it, which is easy to misread otherwise.
            "----- NEWEST FIRST (${lines.size} entries, kept across restarts) -----\n" +
                lines.reversed().joinToString("\n") +
                "\n----- OLDEST -----"
        }

    /**
     * For anything derived from your messages or notes.
     *
     * Making the log persistent was a real improvement for debugging and a
     * quiet regression for privacy: cue text and message excerpts started
     * being written to disk. This keeps the useful signal -- that something
     * happened, and how big it was -- while leaving the content out unless
     * verbose logging is explicitly switched on in Settings.
     */
    fun logContent(ctx: Context, summary: String, detail: String) {
        if (Prefs.verboseLog(ctx)) log("$summary $detail") else log(summary)
    }

    private val seenOnce = HashSet<String>()

    /** For high-frequency noise: logs the first occurrence of a key only. */
    @Synchronized
    fun logOnce(key: String, message: String) {
        if (seenOnce.add(key)) log(message)
    }

    @Synchronized
    fun clear() {
        lines.clear()
        seenOnce.clear()
        flush(force = true)
    }

    fun notificationAccessGranted(ctx: Context): Boolean {
        val enabled = Settings.Secure.getString(
            ctx.contentResolver, "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(ctx.packageName)
    }

    /** Shared by every caller so they all exercise the identical prompt. */
    fun buildPrompt(
        hits: List<Memory>,
        message: String,
        label: String = "Message"
    ): String {
        // Prefill is the slow half of CPU inference, so keep the prompt small.
        val notes = hits.take(3).joinToString("\n") { "- ${it.text.take(200)}" }
        return buildString {
            // A 1B model does better imitating a worked example than following
            // an abstract instruction, and the refusal token is placed LAST so
            // it does not read as the default choice.
            append("Answer the question using only the saved notes.\n\n")
            append("Example\n")
            append("Notes:\n- Flight BA142 leaves 18:40 from Heathrow T5\n")
            append("Message: \"hey what time is your flight again\"\n")
            append("Answer: BA142 at 18:40 from Heathrow T5\n\n")
            append("Now this one\n")
            append("Notes:\n").append(notes).append("\n")
            append(label).append(": \"").append(message.takeLast(500)).append("\"\n")
            append("Answer in under 20 words, using the notes. ")
            append("Only if the notes are completely unrelated, answer: NONE\n")
            append("Answer:")
        }
    }

    @Volatile
    private var lastPrompt: String = ""

    @Volatile
    private var lastAnswer: String = ""

    fun recordExchange(prompt: String, answer: String) {
        lastPrompt = prompt
        lastAnswer = answer
    }

    /** The exact text the model last saw, and exactly what it said back. */
    fun lastExchange(): String =
        if (lastPrompt.isEmpty()) "The model has not run yet in this session."
        else "===== PROMPT SENT =====\n$lastPrompt\n\n===== RAW ANSWER =====\n\"$lastAnswer\""

    /**
     * Walks every gate in the same order the listener does and reports where a
     * real message would have died. Call this off the main thread: the last
     * stage runs actual inference and can take several seconds.
     */
    fun selfTest(ctx: Context, message: String): String {
        val sb = StringBuilder()
        fun line(s: String = "") = sb.append(s).append('\n')

        line("=== Permissions ===")
        line("Cues enabled       : ${Prefs.enabled(ctx)}")
        line("Notification access: ${notificationAccessGranted(ctx)}")
        line("Accessibility svc  : ${ScreenReaderService.instance != null}")
        line("Live screen scan   : ${Prefs.liveScan(ctx)}")

        val watched = Prefs.watchedApps(ctx)
        line()
        line("=== Watched apps (${watched.size}) ===")
        if (watched.isEmpty()) {
            line("NONE TICKED. No notification can ever trigger a cue.")
        } else {
            watched.sorted().forEach { line("  $it") }
        }

        line()
        line("=== Battery gates ===")
        val pm = ctx.getSystemService(PowerManager::class.java)
        line("Battery saver on : ${pm?.isPowerSaveMode}   (blocks cues if true)")
        line("Screen-on gate   : ${Prefs.onlyWhenScreenOn(ctx)}   (screen currently on: ${pm?.isInteractive})")
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        line("Battery level    : $level%   (minimum ${Prefs.minBattery(ctx)}%)")
        line("Cooldown         : ${Prefs.cooldownMs(ctx) / 1000}s per app")

        val all = MemoryStore.all(ctx)
        val unenriched = MemoryStore.withoutKeywords(ctx).size
        line()
        line("=== Memory (${all.size} entries, $unenriched not enriched) ===")
        all.takeLast(5).forEach {
            line("  [${it.source}] ${it.text.take(60)}")
            if (it.keywords.isNotBlank()) line("      words: ${it.keywords.take(90)}")
        }
        if (unenriched > 0) {
            line()
            line("$unenriched entr${if (unenriched == 1) "y has" else "ies have"} no related words yet.")
            line("Tap \"Enrich memories\" so they can match wording they do not contain.")
        }

        line()
        line("=== Prefilter ===")
        line("Test message: \"$message\"")
        if (message.length < 12) {
            line("NOTE: a real notification body under 12 characters is dropped.")
        }
        line(MemoryStore.debugTokens(ctx, message))
        val hits = MemoryStore.relevant(ctx, message)
        if (hits.isEmpty()) {
            line()
            line("NO MATCH -> the model would never be woken.")
            line("Plurals are stemmed, so \"bottles\" does match \"bottle\", but a")
            line("note only matches wording it shares. Run \"Enrich memories\" to")
            line("give each note the related words people actually use.")
            return sb.toString()
        }
        line("Matched ${hits.size} entr${if (hits.size == 1) "y" else "ies"}:")
        hits.forEach { line("  [${it.source}] ${it.text.take(70)}") }

        line()
        line("=== Model ===")
        val path = Prefs.modelPath(ctx)
        val file = path?.let { File(it) }
        line("File: ${Prefs.modelName(ctx).ifEmpty { "(imported before names were recorded)" }}")
        line("Path: ${path ?: "(none selected)"}")
        line("Size: " + if (file != null && file.exists()) "${file.length() / (1024 * 1024)} MB" else "MISSING")
        line("Backend requested: ${Prefs.backendName(Prefs.backend(ctx))}")
        line("Runtime: " + if (LiteRtLmBackend.handles(Prefs.modelName(ctx))) "LiteRT-LM" else "MediaPipe")

        line()
        line("=== Inference ===")
        val startedAt = System.currentTimeMillis()
        val outcome = runCatching { LlmEngine.generate(ctx, buildPrompt(hits, message)) }
        val elapsed = System.currentTimeMillis() - startedAt

        outcome.onSuccess { raw ->
            line("Completed in ${elapsed}ms")
            line("Raw output: \"$raw\"")
            val cleaned = Cue.clean(raw)
            val declined = Cue.isDecline(cleaned) || cleaned.length > 200
            line()
            when {
                !declined -> line("THIS WOULD HAVE BEEN SHOWN AS A CUE.")
                Prefs.fallbackCue(ctx) ->
                    line("Model declined -> the saved note would be shown instead.")
                else ->
                    line("Model declined and the fallback is off, so nothing would appear.")
            }
        }.onFailure { e ->
            line("Failed after ${elapsed}ms")
            line("${e::class.java.simpleName}: ${e.message ?: "(no message)"}")
            line()
            line("A failure here means the .task bundle is not a valid MediaPipe")
            line("Android bundle. The usual causes are a web/WASM build, a")
            line("truncated download, or a context length below the app's 640.")
        }
        return sb.toString()
    }
}
