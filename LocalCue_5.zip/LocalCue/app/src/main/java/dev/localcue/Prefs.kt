package dev.localcue

import android.app.Application
import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "localcue"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun enabled(ctx: Context) = sp(ctx).getBoolean("enabled", true)
    fun setEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("enabled", v).apply()

    fun modelPath(ctx: Context): String? = sp(ctx).getString("model", null)
    fun setModelPath(ctx: Context, v: String) = sp(ctx).edit().putString("model", v).apply()

    /** The file is copied to model.task, so the original name is kept separately. */
    fun modelName(ctx: Context): String = sp(ctx).getString("modelname", "") ?: ""
    fun setModelName(ctx: Context, v: String) = sp(ctx).edit().putString("modelname", v).apply()

    fun useGpu(ctx: Context) = sp(ctx).getBoolean("gpu", false)
    fun setUseGpu(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("gpu", v).apply()
        LlmEngine.unload()
    }

    fun fallbackCue(ctx: Context) = sp(ctx).getBoolean("fallback", true)
    fun setFallbackCue(ctx: Context, v: Boolean) =
        sp(ctx).edit().putBoolean("fallback", v).apply()

    fun liveScan(ctx: Context) = sp(ctx).getBoolean("livescan", true)
    fun setLiveScan(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("livescan", v).apply()
        ScreenReaderService.instance?.applyWatchedPackages()
    }

    fun onlyWhenScreenOn(ctx: Context) = sp(ctx).getBoolean("screenon", true)
    fun setOnlyWhenScreenOn(ctx: Context, v: Boolean) =
        sp(ctx).edit().putBoolean("screenon", v).apply()

    fun minBattery(ctx: Context) = sp(ctx).getInt("minbat", 20)
    fun setMinBattery(ctx: Context, v: Int) = sp(ctx).edit().putInt("minbat", v).apply()

    fun cooldownMs(ctx: Context) = sp(ctx).getInt("cooldown", 90) * 1000L
    fun setCooldownSec(ctx: Context, v: Int) = sp(ctx).edit().putInt("cooldown", v).apply()

    fun watchedApps(ctx: Context): Set<String> =
        sp(ctx).getStringSet("apps", emptySet()) ?: emptySet()

    fun setWatchedApps(ctx: Context, v: Set<String>) {
        sp(ctx).edit().putStringSet("apps", v).apply()
        // Re-narrow the accessibility event filter to the new selection.
        ScreenReaderService.instance?.applyWatchedPackages()
    }
}

class CueApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifications.createChannels(this)
    }
}
