package dev.localcue

import android.app.Application
import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "localcue"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun enabled(ctx: Context) = sp(ctx).getBoolean("enabled", true)
    fun setEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("enabled", v).apply()

    fun modelPath(ctx: Context): String? = sp(ctx).getString("model", null)
    fun setModelPath(ctx: Context, v: String) = sp(ctx).edit().putString("model", v).apply()

    /** The file is copied to model.task, so the original name is kept separately. */
    fun modelName(ctx: Context): String = sp(ctx).getString("modelname", "") ?: ""
    fun setModelName(ctx: Context, v: String) = sp(ctx).edit().putString("modelname", v).apply()

    const val BACKEND_CPU = 0
    const val BACKEND_GPU = 1
    const val BACKEND_NPU = 2

    fun backend(ctx: Context) = sp(ctx).getInt("backend", BACKEND_CPU)
    fun setBackend(ctx: Context, v: Int) {
        sp(ctx).edit().putInt("backend", v).apply()
        // The engine bakes the backend in at load time, so it has to go.
        LlmEngine.unload()
    }

    fun backendName(v: Int) = when (v) {
        BACKEND_GPU -> "GPU"
        BACKEND_NPU -> "NPU"
        else -> "CPU"
    }

    fun fallbackCue(ctx: Context) = sp(ctx).getBoolean("fallback", true)
    fun setFallbackCue(ctx: Context, v: Boolean) =
        sp(ctx).edit().putBoolean("fallback", v).apply()

    /**
     * Off by default. When off, the persisted diagnostics log records that a
     * cue happened and how long it was, but not what it said -- the log lives
     * on disk, and cue text is derived from your messages.
     */
    // ---- Semantic matching -------------------------------------------
    fun embedModelPath(ctx: Context): String? = sp(ctx).getString("embedmodel", null)
    fun setEmbedModelPath(ctx: Context, v: String) {
        sp(ctx).edit().putString("embedmodel", v).apply()
        Embedder.unload()
    }

    fun embedModelName(ctx: Context): String = sp(ctx).getString("embedname", "") ?: ""
    fun setEmbedModelName(ctx: Context, v: String) = sp(ctx).edit().putString("embedname", v).apply()

    fun useEmbeddings(ctx: Context) = sp(ctx).getBoolean("useembed", true)
    fun setUseEmbeddings(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("useembed", v).apply()

    /**
     * Cosine cutoff. 0.6 is a reasonable starting point for EmbeddingGemma:
     * lower cues more often and more loosely, higher is stricter.
     */
    private val THRESHOLDS = floatArrayOf(0.45f, 0.55f, 0.60f, 0.70f, 0.80f)
    fun thresholdChoice(ctx: Context) = sp(ctx).getInt("threshold", 2)
    fun setThresholdChoice(ctx: Context, v: Int) = sp(ctx).edit().putInt("threshold", v).apply()
    fun similarityThreshold(ctx: Context) =
        THRESHOLDS[thresholdChoice(ctx).coerceIn(0, THRESHOLDS.size - 1)]

    /**
     * Ask the chat model which notes relate, when the free paths find nothing
     * and the message is a question. On by default: it is the only route that
     * works for languages with no usable embedder, which right now is most of
     * them.
     */
    const val DEEP_OFF = 0
    const val DEEP_QUESTIONS = 1
    const val DEEP_ALWAYS = 2

    fun deepMode(ctx: Context) = sp(ctx).getInt("deepmode", DEEP_QUESTIONS)
    fun setDeepMode(ctx: Context, v: Int) = sp(ctx).edit().putInt("deepmode", v).apply()

    fun verboseLog(ctx: Context) = sp(ctx).getBoolean("verbose", false)
    fun setVerboseLog(ctx: Context, v: Boolean) =
        sp(ctx).edit().putBoolean("verbose", v).apply()

    fun liveScan(ctx: Context) = sp(ctx).getBoolean("livescan", true)
    fun setLiveScan(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("livescan", v).apply()
        ScreenReaderService.instance?.applyWatchedPackages()
    }

    fun onlyWhenScreenOn(ctx: Context) = sp(ctx).getBoolean("screenon", true)
    fun setOnlyWhenScreenOn(ctx: Context, v: Boolean) =
        sp(ctx).edit().putBoolean("screenon", v).apply()

    // Battery floor, stored as an index into R.array.battery_floors.
    private val BATTERY_FLOORS = intArrayOf(0, 10, 20, 30, 50)
    fun batteryChoice(ctx: Context) = sp(ctx).getInt("batchoice", 2)
    fun setBatteryChoice(ctx: Context, v: Int) = sp(ctx).edit().putInt("batchoice", v).apply()
    fun minBattery(ctx: Context) =
        BATTERY_FLOORS[batteryChoice(ctx).coerceIn(0, BATTERY_FLOORS.size - 1)]

    /**
     * Total context, stored as an index into R.array.context_sizes.
     *
     * 640 is right for a 1B on CPU, where it also bounds a runaway generation.
     * A larger model like Gemma 3n E2B can afford much more, and starving it
     * wastes the reason for loading it.
     */
    private val CONTEXT_SIZES =
        intArrayOf(640, 1280, 2048, 4096, 8192, 16384, 32768)
    fun contextChoice(ctx: Context) = sp(ctx).getInt("ctxchoice", 0)
    fun setContextChoice(ctx: Context, v: Int) {
        sp(ctx).edit().putInt("ctxchoice", v).apply()
        // Baked in at load time, so the engine has to go.
        LlmEngine.unload()
    }
    fun contextTokens(ctx: Context) =
        CONTEXT_SIZES[contextChoice(ctx).coerceIn(0, CONTEXT_SIZES.size - 1)]

    fun cooldownMs(ctx: Context) = sp(ctx).getInt("cooldown", 90) * 1000L
    fun setCooldownSec(ctx: Context, v: Int) = sp(ctx).edit().putInt("cooldown", v).apply()

    fun watchedApps(ctx: Context): Set<String> =
        sp(ctx).getStringSet("apps", emptySet()) ?: emptySet()

    fun setWatchedApps(ctx: Context, v: Set<String>) {
        sp(ctx).edit().putStringSet("apps", v).apply()
        // Re-narrow the accessibility event filter to the new selection.
        ScreenReaderService.instance?.applyWatchedPackages()
    }
}

class CueApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Do this first so anything that logs during startup is captured.
        Diag.attach(this)
        Notifications.createChannels(this)
    }
}
