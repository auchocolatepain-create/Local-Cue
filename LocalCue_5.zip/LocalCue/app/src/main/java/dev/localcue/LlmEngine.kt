package dev.localcue

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.ai.edge.litertlm.Engine as LiteRtLmEngine
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Wraps the on-device model.
 *
 * Concurrency: genuinely single flight. An earlier version was @Synchronized,
 * which made concurrent callers QUEUE rather than be dropped -- a burst of
 * screen updates would stack requests behind one slow inference and nothing
 * ever reported why. Now a second caller gets Busy() immediately.
 *
 * Battery design:
 *  - Loaded lazily on first use, never at boot.
 *  - Unloaded after IDLE_UNLOAD_MS of inactivity, returning ~600 MB of RAM.
 *    The unload defers itself while an inference is in flight, so it can never
 *    close the engine out from under a running call.
 */
object LlmEngine {

    private const val TAG = "LocalCue"
    private const val IDLE_UNLOAD_MS = 3 * 60 * 1000L
    // TOTAL context, not an output cap. MediaPipe has no output limit in the
    // blocking API, so a model that never emits a stop token decodes until it
    // exhausts this budget. Keeping it small is the only hard bound on how long
    // one call can run.
    const val MAX_TOKENS = 640
    private const val WATCHDOG_ONE_MS = 30_000L
    private const val WATCHDOG_TWO_MS = 90_000L

    private var llm: LlmInference? = null
    private var lm: LiteRtLmEngine? = null
    private val main = Handler(Looper.getMainLooper())
    private val busy = AtomicBoolean(false)

    private val unloadTask = object : Runnable {
        override fun run() {
            if (busy.get()) main.postDelayed(this, 30_000L) else unload()
        }
    }

    class ModelMissing : Exception("Model file not found or unreadable")
    class Busy : Exception("A previous inference is still running")

    fun isBusy(): Boolean = busy.get()

    /**
     * Recovery hatch for a call that never returns. The native engine cannot be
     * interrupted, so we deliberately do NOT close it here -- closing while it
     * is mid-generation risks a native crash. We drop our reference instead,
     * which unsticks the app and leaks the old engine until the process ends.
     */
    fun forceReset() {
        llm = null
        lm = null
        busy.set(false)
        Diag.log("model force reset (previous engine abandoned)")
    }

    /** Smallest possible round trip, for measuring real decode speed. */
    fun benchmark(ctx: Context): String {
        val loadStartedAt = System.currentTimeMillis()
        val wasLoaded = isLoaded()
        val out = generate(ctx, "Reply with exactly one word: ready")
        return buildString {
            append(if (wasLoaded) "Model was already loaded.\n" else "Included a cold model load.\n")
            append("Total: ${System.currentTimeMillis() - loadStartedAt}ms\n")
            append("Output: \"").append(out).append("\"")
        }
    }

    fun isLoaded(): Boolean = llm != null || lm != null

    /**
     * Throws Busy immediately if another inference is in flight. Every stage is
     * timed into the diagnostics log so a slow model and a stuck model are
     * distinguishable from the Diagnostics screen alone.
     */
    fun generate(ctx: Context, prompt: String): String {
        if (!busy.compareAndSet(false, true)) throw Busy()

        val watchdogOne = Runnable {
            if (busy.get()) Diag.log("model STILL running after 30s")
        }
        val watchdogTwo = Runnable {
            if (busy.get()) Diag.log("model STILL running after 90s - probably stuck")
        }
        main.postDelayed(watchdogOne, WATCHDOG_ONE_MS)
        main.postDelayed(watchdogTwo, WATCHDOG_TWO_MS)

        val startedAt = System.currentTimeMillis()
        try {
            main.removeCallbacks(unloadTask)

            val wasLoaded = isLoaded()
            val loadStartedAt = System.currentTimeMillis()
            if (!wasLoaded) Diag.log("loading model…")
            val engine: Any = ensureLoaded(ctx)
            if (!wasLoaded) {
                Diag.log("model loaded in ${System.currentTimeMillis() - loadStartedAt}ms")
            }

            Diag.log("generating, prompt is ${prompt.length} chars")
            val generateStartedAt = System.currentTimeMillis()
            val out = when (engine) {
                is LiteRtLmEngine -> LiteRtLmBackend.ask(engine, prompt).trim()
                is LlmInference -> engine.generateResponse(prompt).trim()
                else -> throw IllegalStateException("unknown engine")
            }
            Diag.recordExchange(prompt, out)
            Diag.log(
                "inference finished in ${System.currentTimeMillis() - generateStartedAt}ms " +
                    "(${out.length} chars out)"
            )
            return out
        } finally {
            main.removeCallbacks(watchdogOne)
            main.removeCallbacks(watchdogTwo)
            busy.set(false)
            main.postDelayed(unloadTask, IDLE_UNLOAD_MS)
            Log.i(TAG, "generate() total ${System.currentTimeMillis() - startedAt}ms")
        }
    }

    private fun build(ctx: Context, path: String, backend: LlmInference.Backend): LlmInference {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(MAX_TOKENS)
            .setPreferredBackend(backend)
            .build()
        Log.i(TAG, "Loading model ($backend)")
        return LlmInference.createFromOptions(ctx.applicationContext, options)
    }

    @Synchronized
    private fun ensureLoaded(ctx: Context): Any {
        llm?.let { return it }
        lm?.let { return it }

        val path = Prefs.modelPath(ctx)
        if (path.isNullOrBlank()) throw ModelMissing()
        val file = java.io.File(path)
        if (!file.canRead() || file.length() == 0L) throw ModelMissing()

        // .litertlm goes to the newer runtime, which is the one with working
        // GPU support; .task stays on MediaPipe.
        val name = Prefs.modelName(ctx).ifEmpty { path }
        if (LiteRtLmBackend.handles(name)) {
            val created = LiteRtLmBackend.create(ctx, path)
            lm = created
            return created
        }

        val wantGpu = Prefs.backend(ctx) != Prefs.BACKEND_CPU
        val created = if (wantGpu) {
            runCatching { build(ctx, path, LlmInference.Backend.GPU) }
                .onFailure {
                    Log.w(TAG, "GPU backend failed, falling back to CPU", it)
                    Diag.log("MediaPipe GPU backend failed, falling back to CPU")
                }
                .getOrElse { build(ctx, path, LlmInference.Backend.CPU) }
        } else {
            build(ctx, path, LlmInference.Backend.CPU)
        }

        llm = created
        return created
    }

    @Synchronized
    fun unload() {
        llm?.let {
            runCatching { it.close() }
            Log.i(TAG, "Model unloaded")
            Diag.log("model unloaded (idle)")
        }
        lm?.let {
            runCatching { it.close() }
            Diag.log("LiteRT-LM engine unloaded (idle)")
        }
        llm = null
        lm = null
    }
}
