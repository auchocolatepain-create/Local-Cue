package dev.localcue

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/**
 * Wraps the on-device model.
 *
 * Battery design:
 *  - The model is loaded lazily on first use, never at boot.
 *  - It is unloaded again after IDLE_UNLOAD_MS of inactivity, returning
 *    roughly 600 MB of RAM and guaranteeing zero background cost.
 *  - Only one inference runs at a time (synchronized), so a burst of
 *    notifications can never spawn parallel work.
 */
object LlmEngine {

    private const val TAG = "LocalCue"
    private const val IDLE_UNLOAD_MS = 3 * 60 * 1000L

    private var llm: LlmInference? = null
    private val main = Handler(Looper.getMainLooper())
    private val unloadTask = Runnable { unload() }

    class ModelMissing : Exception("Model file not found or unreadable")

    @Synchronized
    fun generate(ctx: Context, prompt: String, maxOutputTokens: Int = 64): String {
        val engine = ensureLoaded(ctx)
        main.removeCallbacks(unloadTask)
        return try {
            engine.generateResponse(prompt).trim()
        } finally {
            main.postDelayed(unloadTask, IDLE_UNLOAD_MS)
        }
    }

    @Synchronized
    private fun ensureLoaded(ctx: Context): LlmInference {
        llm?.let { return it }

        val path = Prefs.modelPath(ctx)
        if (path.isNullOrBlank() || !java.io.File(path).canRead()) throw ModelMissing()

        val backend =
            if (Prefs.useGpu(ctx)) LlmInference.Backend.GPU else LlmInference.Backend.CPU

        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(1280)
            .setPreferredBackend(backend)
            .build()

        Log.i(TAG, "Loading model ($backend)")
        val created = LlmInference.createFromOptions(ctx.applicationContext, options)
        llm = created
        return created
    }

    @Synchronized
    fun unload() {
        llm?.let {
            runCatching { it.close() }
            Log.i(TAG, "Model unloaded")
        }
        llm = null
    }

    fun isLoaded(): Boolean = llm != null
}
