package dev.localcue

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Wraps the on-device model.
 *
 * Concurrency: genuinely single flight. An earlier version was @Synchronized,
 * which made concurrent callers QUEUE rather than be dropped -- a burst of
 * screen updates would stack requests behind one slow inference and nothing
 * ever reported why. Now a second caller gets Busy() immediately.
 *
 * Battery design:
 *  - Loaded lazily on first use, never at boot.
 *  - Unloaded after IDLE_UNLOAD_MS of inactivity, returning ~600 MB of RAM.
 *    The unload defers itself while an inference is in flight, so it can never
 *    close the engine out from under a running call.
 */
object LlmEngine {

    private const val TAG = "LocalCue"
    private const val IDLE_UNLOAD_MS = 3 * 60 * 1000L
    private const val MAX_TOKENS = 1280
    private const val WATCHDOG_ONE_MS = 30_000L
    private const val WATCHDOG_TWO_MS = 90_000L

    private var llm: LlmInference? = null
    private val main = Handler(Looper.getMainLooper())
    private val busy = AtomicBoolean(false)

    private val unloadTask = object : Runnable {
        override fun run() {
            if (busy.get()) main.postDelayed(this, 30_000L) else unload()
        }
    }

    class ModelMissing : Exception("Model file not found or unreadable")
    class Busy : Exception("A previous inference is still running")

    fun isBusy(): Boolean = busy.get()

    fun isLoaded(): Boolean = llm != null

    /**
     * Throws Busy immediately if another inference is in flight. Every stage is
     * timed into the diagnostics log so a slow model and a stuck model are
     * distinguishable from the Diagnostics screen alone.
     */
    fun generate(ctx: Context, prompt: String): String {
        if (!busy.compareAndSet(false, true)) throw Busy()

        val watchdogOne = Runnable {
            if (busy.get()) Diag.log("model STILL running after 30s")
        }
        val watchdogTwo = Runnable {
            if (busy.get()) Diag.log("model STILL running after 90s - probably stuck")
        }
        main.postDelayed(watchdogOne, WATCHDOG_ONE_MS)
        main.postDelayed(watchdogTwo, WATCHDOG_TWO_MS)

        val startedAt = System.currentTimeMillis()
        try {
            main.removeCallbacks(unloadTask)

            val wasLoaded = llm != null
            val loadStartedAt = System.currentTimeMillis()
            if (!wasLoaded) Diag.log("loading model…")
            val engine = ensureLoaded(ctx)
            if (!wasLoaded) {
                Diag.log("model loaded in ${System.currentTimeMillis() - loadStartedAt}ms")
            }

            Diag.log("generating, prompt is ${prompt.length} chars")
            val generateStartedAt = System.currentTimeMillis()
            val out = engine.generateResponse(prompt).trim()
            Diag.log(
                "inference finished in ${System.currentTimeMillis() - generateStartedAt}ms " +
                    "(${out.length} chars out)"
            )
            return out
        } finally {
            main.removeCallbacks(watchdogOne)
            main.removeCallbacks(watchdogTwo)
            busy.set(false)
            main.postDelayed(unloadTask, IDLE_UNLOAD_MS)
            Log.i(TAG, "generate() total ${System.currentTimeMillis() - startedAt}ms")
        }
    }

    private fun build(ctx: Context, path: String, backend: LlmInference.Backend): LlmInference {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(MAX_TOKENS)
            .setPreferredBackend(backend)
            .build()
        Log.i(TAG, "Loading model ($backend)")
        return LlmInference.createFromOptions(ctx.applicationContext, options)
    }

    @Synchronized
    private fun ensureLoaded(ctx: Context): LlmInference {
        llm?.let { return it }

        val path = Prefs.modelPath(ctx)
        if (path.isNullOrBlank()) throw ModelMissing()
        val file = java.io.File(path)
        if (!file.canRead() || file.length() == 0L) throw ModelMissing()

        val created = if (Prefs.useGpu(ctx)) {
            runCatching { build(ctx, path, LlmInference.Backend.GPU) }
                .onFailure {
                    Log.w(TAG, "GPU backend failed, falling back to CPU", it)
                    Diag.log("GPU backend failed, falling back to CPU")
                }
                .getOrElse { build(ctx, path, LlmInference.Backend.CPU) }
        } else {
            build(ctx, path, LlmInference.Backend.CPU)
        }

        llm = created
        return created
    }

    @Synchronized
    fun unload() {
        llm?.let {
            runCatching { it.close() }
            Log.i(TAG, "Model unloaded")
            Diag.log("model unloaded (idle)")
        }
        llm = null
    }
}
