package dev.localcue

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/**
 * Wraps the on-device model.
 *
 * Battery design:
 *  - The model is loaded lazily on first use, never at boot.
 *  - It is unloaded again after IDLE_UNLOAD_MS of inactivity, returning
 *    roughly 600 MB of RAM and guaranteeing zero background cost.
 *  - Only one inference runs at a time (synchronized), so a burst of
 *    notifications can never spawn parallel work.
 */
object LlmEngine {

    private const val TAG = "LocalCue"
    private const val IDLE_UNLOAD_MS = 3 * 60 * 1000L
    private const val MAX_TOKENS = 1280

    private var llm: LlmInference? = null
    private val main = Handler(Looper.getMainLooper())
    private val unloadTask = Runnable { unload() }

    class ModelMissing : Exception("Model file not found or unreadable")

    @Synchronized
    fun generate(ctx: Context, prompt: String): String {
        val engine = ensureLoaded(ctx)
        main.removeCallbacks(unloadTask)
        return try {
            engine.generateResponse(prompt).trim()
        } finally {
            main.postDelayed(unloadTask, IDLE_UNLOAD_MS)
        }
    }

    private fun build(ctx: Context, path: String, backend: LlmInference.Backend): LlmInference {
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(path)
            .setMaxTokens(MAX_TOKENS)
            .setPreferredBackend(backend)
            .build()
        Log.i(TAG, "Loading model ($backend)")
        return LlmInference.createFromOptions(ctx.applicationContext, options)
    }

    @Synchronized
    private fun ensureLoaded(ctx: Context): LlmInference {
        llm?.let { return it }

        val path = Prefs.modelPath(ctx)
        if (path.isNullOrBlank()) throw ModelMissing()
        val file = java.io.File(path)
        if (!file.canRead() || file.length() == 0L) throw ModelMissing()

        val wantGpu = Prefs.useGpu(ctx)
        val created = if (wantGpu) {
            // Tensor G5's TPU is not reachable from third-party inference and the
            // GPU delegate fails on some builds, so never let that be fatal.
            runCatching { build(ctx, path, LlmInference.Backend.GPU) }
                .onFailure { Log.w(TAG, "GPU backend failed, falling back to CPU", it) }
                .getOrElse { build(ctx, path, LlmInference.Backend.CPU) }
        } else {
            build(ctx, path, LlmInference.Backend.CPU)
        }

        llm = created
        return created
    }

    @Synchronized
    fun unload() {
        llm?.let {
            runCatching { it.close() }
            Log.i(TAG, "Model unloaded")
        }
        llm = null
    }

    fun isLoaded(): Boolean = llm != null
}
