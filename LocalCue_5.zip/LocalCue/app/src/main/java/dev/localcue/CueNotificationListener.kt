package dev.localcue

import android.app.Notification
import android.os.BatteryManager
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * The cue trigger.
 *
 * This service is bound by the system and sits completely idle until a
 * notification arrives -- there is no polling and no timer, so it costs
 * nothing when nothing is happening.
 *
 * Incoming message text is used to decide whether a cue is warranted and is
 * then discarded. It is never written to memory or anywhere else on disk.
 */
class CueNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lastCueAt = HashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        if (!Prefs.watchedApps(this).contains(pkg)) return
        if (!Prefs.enabled(this)) return

        // --- Battery gates, cheapest first -------------------------------
        val pm = getSystemService(PowerManager::class.java)
        if (pm?.isPowerSaveMode == true) return
        if (Prefs.onlyWhenScreenOn(this) && pm?.isInteractive == false) return

        val bm = getSystemService(BatteryManager::class.java)
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        if (level < Prefs.minBattery(this)) return

        // One cue per app per cooldown window.
        val now = System.currentTimeMillis()
        val last = lastCueAt[pkg] ?: 0L
        if (now - last < Prefs.cooldownMs(this)) return

        // --- Extract the message -----------------------------------------
        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val message = "$title: $body".trim()
        if (body.length < 12) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        // --- The prefilter: keeps the model asleep most of the time -------
        val hits = MemoryStore.relevant(this, message)
        if (hits.isEmpty()) return

        lastCueAt[pkg] = now

        scope.launch {
            runCatching {
                val context = hits.joinToString("\n") { "- ${it.text.take(400)}" }
                val prompt = buildString {
                    append("You are a private assistant with access to notes the user saved.\n\n")
                    append("Saved notes:\n").append(context).append("\n\n")
                    append("Incoming message: \"").append(message.take(400)).append("\"\n\n")
                    append("If one of the saved notes directly answers or helps with this ")
                    append("message, reply with that fact in under 15 words. ")
                    append("If not, reply with exactly: NOTHING")
                }

                val answer = LlmEngine.generate(applicationContext, prompt)
                val cleaned = answer.trim().trim('"', '.', ' ')

                if (cleaned.isNotEmpty() &&
                    !cleaned.equals("NOTHING", ignoreCase = true) &&
                    !cleaned.contains("NOTHING", ignoreCase = true) &&
                    cleaned.length < 200
                ) {
                    Notifications.showCue(applicationContext, cleaned)
                }
            }.onFailure {
                Log.w("LocalCue", "cue failed", it)
                if (it is LlmEngine.ModelMissing) {
                    Notifications.showProblem(applicationContext, getString(R.string.no_model))
                }
            }
        }
    }

    override fun onListenerDisconnected() {
        LlmEngine.unload()
    }
}
