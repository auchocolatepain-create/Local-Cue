package dev.localcue

import android.app.Notification
import android.os.BatteryManager
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * The cue trigger.
 *
 * This service is bound by the system and sits completely idle until a
 * notification arrives -- there is no polling and no timer, so it costs
 * nothing when nothing is happening.
 *
 * Incoming message text is used to decide whether a cue is warranted and is
 * then discarded. It is never written to memory or anywhere else on disk.
 *
 * Every exit path records a one-line reason in Diag so the Diagnostics screen
 * can show exactly why a message produced no cue.
 */
class CueNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lastCueAt = HashMap<String, Long>()

    override fun onListenerConnected() {
        Diag.log("listener connected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return

        if (!Prefs.enabled(this)) {
            Diag.log("$pkg -> skipped: cues are turned off")
            return
        }
        if (!Prefs.watchedApps(this).contains(pkg)) {
            // Logged once per package. Android itself posts notifications under
            // "android", and repeating that line buries the useful entries.
            Diag.logOnce("notticked:$pkg", "$pkg -> ignored: app not ticked")
            return
        }

        // --- Battery gates, cheapest first -------------------------------
        val pm = getSystemService(PowerManager::class.java)
        if (pm?.isPowerSaveMode == true) {
            Diag.log("$pkg -> skipped: battery saver is on")
            return
        }
        if (Prefs.onlyWhenScreenOn(this) && pm?.isInteractive == false) {
            Diag.log("$pkg -> skipped: screen is off")
            return
        }

        val bm = getSystemService(BatteryManager::class.java)
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        if (level < Prefs.minBattery(this)) {
            Diag.log("$pkg -> skipped: battery $level% below ${Prefs.minBattery(this)}%")
            return
        }

        // One cue per app per cooldown window.
        val now = System.currentTimeMillis()
        val last = lastCueAt[pkg] ?: 0L
        if (now - last < Prefs.cooldownMs(this)) {
            val wait = (Prefs.cooldownMs(this) - (now - last)) / 1000
            Diag.log("$pkg -> skipped: cooldown, ${wait}s remaining")
            return
        }

        // --- Extract the message -----------------------------------------
        val extras = sbn.notification?.extras ?: return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            Diag.log("$pkg -> skipped: group summary notification")
            return
        }
        // EXTRA_TEXT alone is often a summary like "3 new messages". Messaging
        // apps put the real content in BIG_TEXT or TEXT_LINES, so prefer those.
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val plain = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.joinToString("\n") { it.toString() }
            .orEmpty()
        val body = listOf(lines, big, plain).firstOrNull { it.length > plain.length } ?: plain
        val message = "$title: $body".trim()
        if (body.length < 12) {
            Diag.log("$pkg -> skipped: body too short (${body.length} chars)")
            return
        }

        // --- The prefilter: keeps the model asleep most of the time -------
        val hits = MemoryStore.relevant(this, message)
        if (hits.isEmpty()) {
            Diag.logContent(
                this,
                "$pkg -> skipped: no memory overlaps this message",
                "\"${message.take(50)}\""
            )
            return
        }

        if (LlmEngine.isBusy()) {
            Diag.log("$pkg -> skipped: model still busy with an earlier message")
            return
        }

        lastCueAt[pkg] = now
        Diag.log("$pkg -> ${hits.size} memory match(es), waking model")

        scope.launch {
            runCatching {
                val answer = LlmEngine.generate(applicationContext, Diag.buildPrompt(hits, message))
                Cue.deliver(applicationContext, answer, hits, "notification")
            }.onFailure {
                if (it is LlmEngine.Busy) {
                    Diag.log("model busy, dropped")
                    return@onFailure
                }
                // Previously this was swallowed silently, which made a bad model
                // file indistinguishable from "nothing was relevant".
                Log.w("LocalCue", "cue failed", it)
                Diag.log("INFERENCE FAILED: ${it::class.java.simpleName}: ${it.message}")
                val text = if (it is LlmEngine.ModelMissing) {
                    getString(R.string.no_model)
                } else {
                    getString(R.string.model_error, it.message?.take(100) ?: "unknown")
                }
                Notifications.showProblem(applicationContext, text)
            }
        }
    }

    override fun onListenerDisconnected() {
        Diag.log("listener disconnected")
        LlmEngine.unload()
    }
}
