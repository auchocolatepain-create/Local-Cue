package dev.localcue

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

/**
 * Lets you choose exactly which apps can trigger a cue.
 * Nothing is watched until you tick it here.
 */
class AppPickerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName != packageName }
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || isLikelyMessaging(it.packageName) }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        val labels = apps.map { pm.getApplicationLabel(it).toString() }
        val selected = Prefs.watchedApps(this).toMutableSet()

        val list = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            adapter = ArrayAdapter(
                this@AppPickerActivity,
                android.R.layout.simple_list_item_multiple_choice,
                labels
            )
        }
        setContentView(list)

        apps.forEachIndexed { i, a ->
            if (selected.contains(a.packageName)) list.setItemChecked(i, true)
        }

        list.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].packageName
            if (list.isItemChecked(pos)) selected.add(pkg) else selected.remove(pkg)
            Prefs.setWatchedApps(this, selected.toSet())
        }
    }

    private fun isLikelyMessaging(pkg: String) = listOf(
        "messaging", "messenger", "whatsapp", "telegram", "signal", "sms", "mms", "chat"
    ).any { pkg.contains(it, ignoreCase = true) }
}
