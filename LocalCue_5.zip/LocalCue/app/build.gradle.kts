plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.localcue"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.localcue"
        minSdk = 31
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"

        // This phone is arm64. Shipping the other ABIs was adding tens of
        // megabytes of native libraries that can never execute here.
        ndk { abiFilters += "arm64-v8a" }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // kotlinOptions{} is the old KGP 1.x surface. compilerOptions{} is the
    // form that is stable from Kotlin 2.0 through 2.3.


    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    // On-device inference. Both are Google local-compute runtimes; neither is
    // permitted to reach the network because the app has no INTERNET permission
    // and the manifest strips any that a dependency tries to merge in.
    //
    // MediaPipe reads .task bundles.
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    // TextEmbedder, for EmbeddingGemma. Semantic matching replaces the keyword
    // guessing that could never connect a name to a question about it.
    implementation("com.google.mediapipe:tasks-text:0.10.27")
    // LiteRT-LM reads .litertlm bundles and is the runtime with working GPU
    // acceleration, plus the larger multilingual models (Gemma 3n, Gemma 4).
    //
    // PINNED deliberately. This artifact is compiled with Kotlin 2.3.0, so the
    // project's Kotlin plugin must be >= 2.3 or the compiler cannot read its
    // metadata. Bumping this version may require bumping Kotlin too.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.16.1")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
