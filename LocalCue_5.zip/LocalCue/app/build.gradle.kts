plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.localcue"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.localcue"
        minSdk = 31
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"

        // This phone is arm64. Shipping the other ABIs was adding tens of
        // megabytes of native libraries that can never execute here.
        ndk { abiFilters += "arm64-v8a" }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    // On-device inference. Both are Google local-compute runtimes; neither is
    // permitted to reach the network because the app has no INTERNET permission
    // and the manifest strips any that a dependency tries to merge in.
    //
    // MediaPipe reads .task bundles.
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    // LiteRT-LM reads .litertlm bundles and is the runtime with working GPU
    // acceleration, plus the larger multilingual models (Gemma 3n, Gemma 4).
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
